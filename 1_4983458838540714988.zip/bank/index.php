<html lang="es-CO">

<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="lang" content="es-CO">
	<meta name="resource-type" content="document">
	<meta name="global" content="distribution">
	<meta name="robots" content="index, follow">
	<meta name="author" content="BBVA">
	<meta name="description" content="Accede a BBVA net y consulta el saldo de tus productos, realiza transferencias, paga tus servicios y realiza más operaciones con toda seguridad ¡Ingresa!" lang="es-CO">
	<meta name="keywords" content="bbva net, acceso net, net, bbva net colombia" lang="es-CO">
	<meta scheme="W3CDTF" name="date" content="November 28, 2021 12:00:00 +0000">
	<meta scheme="W3CDTF" name="DC.date" content="November 28, 2021 12:00:00 +0000">
	<meta name="DC.date.issue" content="November 28, 2021 12:00:00 +0000">
	<meta name="last-modified" content="November 28, 2021 12:00:00 +0000">
	<meta name="pageDate" content="November 28, 2021 12:00:00 +0000">
	<meta name="DC.date" content="November 28, 2021 12:00:00 +0000">
	<meta name="pageRender" content="November 28, 2021 12:00:00 +0000">
	<meta itemprop="datePublished" content="November 28, 2021 12:00:00 +0000">
	<meta scheme="RFC1766" name="DC.language" content="es-CO">
	<meta name="DC.title" content="BBVA COLOMBIA" lang="es-CO">
	<meta name="twitter:title" content="Acceso | BBVA Colombia">
	<meta name="twitter:description" content="Accede a BBVA net y consulta el saldo de tus productos, realiza transferencias, paga tus servicios y realiza más operaciones con toda seguridad ¡Ingresa!">
	<meta name="twitter:card" content="summary">
	<meta property="og:title" content="Acceso | BBVA Colombia">
	<meta property="og:description" content="Accede a BBVA net y consulta el saldo de tus productos, realiza transferencias, paga tus servicios y realiza más operaciones con toda seguridad ¡Ingresa!">
	<meta property="og:type" content="website">
	<meta property="og:url" content="https://www.bbva.com.co/personas/acceso.html">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<meta property="fb:pages" content="https://www.facebook.com/bbvaencolombia/">
	<meta name="search_segment" content="personas">

	<script type="text/javascript">
	window.digitalData = {
		"application": {
			"application": {
				"name": "",
				"type": ""
			},
			"customFields": "",
			"earnings": "",
			"errorType": "",
			"expenses": "",
			"fulfillmentModel": "",
			"globalApplication": "",
			"interactionLevel": "",
			"isQualifiedVisits": "",
			"offer": "",
			"operationNumber": "",
			"process": "",
			"programTypeHired": "",
			"state": "",
			"step": "",
			"transactionID": "",
			"typology": ""
		},
		"internalCampaign": {
			"attributes": [],
			"event": {
				"eventInfo": {
					"eventName": "",
					"siteActionName": ""
				}
			}
		},
		"optimization": {
			"attributes": [],
			"event": []
		},
		"page": {
			"pageActivity": {
				"audio": {
					"nameOfPodcastDisplayed": ""
				},
				"link": {
					"aux1": "",
					"aux2": "",
					"aux3": "",
					"ext": "",
					"name": "",
					"url": ""
				},
				"loginType": "",
				"search": {
					"onSiteSearchEnterTerm": "",
					"onSiteSearchResults": "",
					"onSiteSearchTerm": ""
				},
				"video": {
					"nameOfVideoDisplayed": ""
				}
			},
			"pageInfo": {
				"area": "publica",
				"businessUnit": "BBVA Colombia",
				"channel": "online",
				"errorPage": "",
				"geoRegion": "",
				"language": "ES",
				"level1": "acceso",
				"level10": "",
				"level2": "",
				"level3": "",
				"level4": "",
				"level5": "",
				"level6": "",
				"level7": "",
				"level8": "",
				"level9": "",
				"pageIntent": "informacion",
				"pageName": "escritorio:publica:personas:acceso",
				"pageSegment": "personas",
				"projectName": "",
				"server": "",
				"siteAppName": "BBVA Colombia",
				"sysEnv": "escritorio",
				"version": "1.1.0"
			}
		},
		"pageInstanceID": "pro",
		"products": {
			"attributes": [],
			"productPortfolio": []
		},
		"user": {
			"age": "",
			"civilStatus": "",
			"country": "",
			"device": {
				"root": "",
				"mobile": "",
				"userAgent": ""
			},
			"educationLevel": "",
			"gender": "",
			"jobType": "",
			"profileID": "",
			"prospectID": "",
			"segment": {
				"profile": "",
				"global": ""
			},
			"state": "",
			"userID": "",
			"userState": "no logado"
		},
		"versionDL": "20190718_4.0"
	};
	window.digitalData.user.device.mobile = (function(a) {
		if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g|nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) return 'si';
		return 'no';
	})(navigator.userAgent || navigator.vendor || window.opera);
	window.digitalData.user.device.userAgent = window.navigator.userAgent;
	window.digitalData.page.pageInfo.server = window.location.host;
	</script>
	<!-- This file can be overwritten in any page to add specific data in the header.-->
	<script type="text/javascript">
	var lazycss = lazycss ? lazycss : [];
	</script>
	<script type="text/javascript">
	var lazycsskeys = lazycsskeys ? lazycsskeys : [];
	</script>
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.critical/small.lc-20211111-085347-lc.min.ACSHASH3f4c4e82fba90f26052a1e40b68837b5.css" type="text/css">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.critical/large.lc-20211111-085347-lc.min.ACSHASHda2ffa67489b67d75fb66b15abe18fda.css" type="text/css" media="all and (min-width: 600px)">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.common.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iconfonts/small.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iconfonts/large.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.lightbox/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.lightbox/large.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.radiobutton.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.sectionTitle.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.videoLink/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.videoLink/large.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<script type="text/javascript" class="lazyCSS">
	if(!lazycss) {
		lazycss = [];
	}
	if(!lazycsskeys) {
		lazycsskeys = [];
	}
	var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iframe.lc-20211111-085347-lc.min.css";
	if(lazycsskeys.indexOf(lazycsskey) === -1) {
		lazycsskeys.push(lazycsskey);
		lazycss.push({
			rel: "stylesheet",
			href: lazycsskey,
			type: "text/css",
			media: "print",
			onload: "this.media='all'"
		});
	}
	</script>
	<script>
	! function() {
		var e = new URLSearchParams(window.location.search);
		e && e.has("theme") && localStorage.setItem("theme", e.get("theme"));
		var t = localStorage.getItem("theme");
		if(t) {
			["dark"].includes(t) && document.querySelector("html").classList.add(t + "-theme")
		}
	}();
	</script>
	<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/">
	<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/">
	<link rel="icon" type="image/png" sizes="48x48" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/favicon-48x48.png">
	<link rel="apple-touch-icon" sizes="180x180" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="192x192" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="16x16" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/favicon-16x16.png">
	<link rel="manifest" href="https://www.bbva.com.co/apps/settings/wcm/designs/bbva/img/favicons/v1/site.webmanifest">
	<link rel="mask-icon" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/safari-pinned-tab.svg" color="#1464a5">
	<link rel="shortcut icon" href="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/favicon.ico">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="https://www.bbva.com.co/content/dam/public-web/global/images/favicon/v1/mstile-144x144.png">
	<meta name="msapplication-config" content="https://www.bbva.com.co/apps/settings/wcm/designs/bbva/img/favicons/v1/browserconfig.xml">
	<meta name="theme-color" content="#ffffff">
	<link rel="alternate" type="application/rss+xml" title="RSS" href="https://www.youtube.com/BBVAenColombia">
	<link rel="canonical" href="https://www.bbva.com.co/personas/acceso.html">
	<title>Acceso | BBVA Colombia</title>
	<script type="text/javascript">
	// define a readonly the BE editor mode state.
	window.AEMeditorMode = false;
	</script>
	<script src="//assets.adobedtm.com/95c3e405673d/f5cc53521c75/launch-0a41857cf50a.min.js" async=""></script>
	<script src="https://www.googletagmanager.com/gtag/js?id=AW-943963069" async=""></script>
	<script src="https://assets.adobedtm.com/extensions/EPb56e12d7054b4acea984e91c910051cc/AppMeasurement.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/extensions/EPb56e12d7054b4acea984e91c910051cc/AppMeasurement_Module_ActivityMap.min.js" async=""></script>
	<script src="https://connect.facebook.net/signals/config/365136983864263?v=2.9.48&amp;r=stable" async=""></script>
	<script src="https://connect.facebook.net/signals/plugins/identity.js?v=2.9.48" async=""></script>
	<script src="https://connect.facebook.net/en_US/fbevents.js" async=""></script>
	<script src="https://static.ads-twitter.com/uwt.js" async=""></script>
	<script src="https://www.google-analytics.com/analytics.js" async=""></script>
	<script src="https://www.googletagmanager.com/gtag/js?id=DC-10352449"></script>
	<script src="https://p.teads.tv/teads-fellow.js" async="" type="text/javascript"></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RC8090e94acfba4746902a6ab3167b685e-source.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RC65611586fe394dc89fc108e2cfa94922-source.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RCa9d0b1f93d684797a1e4ab640bf857a8-source.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RCcfe34924ef124d748e8b063216a4dd62-source.min.js" async=""></script>
	<meta http-equiv="origin-trial" content="A7dYd5kJpPZNPkzPzk/uHFiBHh1Vy63H7igyI2Dq4m+1d0no9YKaNYQNfAFW3Us09f1k/SiOQW/LKTSjGuLAXg0AAAB+eyJvcmlnaW4iOiJodHRwczovL3RlYWRzLnR2OjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2NDMxNTUxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9">
	<script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/943963069/?random=1638143736540&amp;cv=9&amp;fst=1638143736540&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=990&amp;u_w=1584&amp;u_ah=963&amp;u_aw=1584&amp;u_cd=24&amp;u_his=1&amp;u_tz=-300&amp;u_java=false&amp;u_nplug=0&amp;u_nmime=0&amp;gtm=2oaba1&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fwww.bbva.com.co%2Fpersonas%2Facceso.html%3Ftms-tagging-cta%3Dbbvanet_acceso_botton&amp;tiba=Acceso%20%7C%20BBVA%20Colombia&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><img alt="" style="position: absolute;" src="https://t.teads.tv/track?action=pageView&amp;env=js-web&amp;tag_version=4.2.4_a3e5121&amp;advertiser_id=11766&amp;referer=https%3A%2F%2Fwww.bbva.com.co%2Fpersonas%2Facceso.html%3Ftms-tagging-cta%3Dbbvanet_acceso_botton" width="0" height="0">
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RCc1ff794c0b494d9c85155df419b34929-source.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RC4767689f46664b8b9af1010b4e4d86bf-source.min.js" async=""></script>
	<script src="https://assets.adobedtm.com/95c3e405673d/f5cc53521c75/bff2f5ac1a0a/RC16c4b9a46b9148c4ad51066e03d4b623-source.min.js" async=""></script>
</head>

<body class="bbva__base" itemscope="" itemtype="http://schema.org/WebPage">
	<div class="general-wrapper">
		<!-- This file is being overwritten in the configuration page to allow the edition of the header alert
     or other header components which can be edited into the configuration template.
 -->
		<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.header/small.lc-20211111-085347-lc.min.ACSHASH2e8d97bb1a5620d91ffbabe238b9e26d.css" type="text/css">
		<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.header/large.lc-20211111-085347-lc.min.ACSHASHf2abe09e37ea20c7751c9867a9bc7863.css" type="text/css" media="all and (min-width: 600px)">
		<header class="header__base wrapper" data-component="tabulation">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.alert/small.lc-20211111-085347-lc.min.ACSHASHabacfb26792d8b1ee9a8f337d0f3be5e.css" type="text/css">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.alert/large.lc-20211111-085347-lc.min.ACSHASH1aac9776566f75b8d0ee57fdc3a6754b.css" type="text/css" media="all and (min-width: 600px)">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.stickyalert.lc-20211111-085347-lc.min.ACSHASH0cef8f8c276b6349ca014f53d495361a.css" type="text/css">
			<div class="cookies alert--full alert--extra"> </div>
			<div> </div>
			<script type="text/javascript" class="lazyCSS">
			if(!lazycss) {
				lazycss = [];
			}
			if(!lazycsskeys) {
				lazycsskeys = [];
			}
			var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.animations.lc-20211111-085347-lc.min.css";
			if(lazycsskeys.indexOf(lazycsskey) === -1) {
				lazycsskeys.push(lazycsskey);
				lazycss.push({
					rel: "stylesheet",
					href: lazycsskey,
					type: "text/css",
					media: "print",
					onload: "this.media='all'"
				});
			}
			</script>
			<script type="text/javascript" class="lazyCSS">
			if(!lazycss) {
				lazycss = [];
			}
			if(!lazycsskeys) {
				lazycsskeys = [];
			}
			var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.skip2content.lc-20211111-085347-lc.min.css";
			if(lazycsskeys.indexOf(lazycsskey) === -1) {
				lazycsskeys.push(lazycsskey);
				lazycss.push({
					rel: "stylesheet",
					href: lazycsskey,
					type: "text/css",
					media: "print",
					onload: "this.media='all'"
				});
			}
			</script> <a class="skip2content invisible" tab-index="0" href="#main" aria-label="Ir al contenido principal">
    Ir al contenido principal
</a>
			<nav class="header__container background--navy" aria-label="bbva colombia" data-component="header" data-dl-component="" data-dl-component-name="header" data-dl-component-type="bbva/pwebs/components/par/header" id="header" data-component-id="3cea50a5-ad4a-41cb-8483-3043491779ec">
				<div class="header__main container">
					<div class="header__wrapper">
						<div class="header__logo" data-component="svgLogoFix" itemscope="" itemtype="http://schema.org/Organization" data-component-id="16e1ec97-6c87-4851-afc1-cf62f8d72095">
							<a itemscope="url" class="header__logo__link " href="https://www.bbva.com.co" target="_self" aria-label="home bbva colombia" title="bbva colombia"> <img data-component-params="{&quot;keepSize&quot;: &quot;&quot; }" src="https://www.bbva.com.co/content/dam/public-web/global/images/logos/logo_bbva_blanco.svg" srcset="https://www.bbva.com.co/content/dam/public-web/global/images/logos/logo_bbva_blanco.svg" sizes="(min-width: 900px) 20vw, 50vw" itemprop="logo" class="header__image " alt="bbva colombia" role="img"> </a>
						</div>
						<div class="header__mainnavigation" itemscope="" itemtype="https://schema.org/SiteNavigationElement">
							<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.mainNavigation/small.lc-20211111-085347-lc.min.ACSHASHa37a04db69bc42a5e08c4323c3bfefe8.css" type="text/css">
							<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.mainNavigation/large.lc-20211111-085347-lc.min.ACSHASH8f81358eebb18a1778ddd3319a401956.css" type="text/css" media="all and (min-width: 600px)">
							<nav class="mainnavigation__base">
								<ul class="mainnavigation__list">
									<li itemprop="name" class="mainnavigation__item mainnavigation__item--active"> <a itemprop="url" aria-label="Personas Opción seleccionada" target="_self" class="mainnavigation__link" href="/">Personas</a> </li>
									<li itemprop="name" class="mainnavigation__item"> <a itemprop="url" aria-label="Empresas " target="_self" class="mainnavigation__link" href="/empresas.html">Empresas</a> </li>
								</ul>
							</nav>
						</div>
					</div>
					<nav class="header__actions" itemscope="" itemtype="https://schema.org/SiteNavigationElement">
						<ul class="header__actions__ulist">
							<li itemprop="name" class="header__actions__list header__actions--tablet-hidden header__actions--mobile-hidden">
								<a itemprop="url" class="header__actions__item__link header__createaccount" href="https://www.bbva.com.co/personas/registrate.html"> <img class="bbva-svgicon bbva-svgicon--largemobile" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_051_newclient.svg" alt=""> <span>Regístrate</span> </a>
							</li>
							<li itemprop="name" class="header__actions__list header__actions--tablet-left">
								<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.access/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
								<script type="text/javascript" class="lazyCSS">
								if(!lazycss) {
									lazycss = [];
								}
								if(!lazycsskeys) {
									lazycsskeys = [];
								}
								var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.access/large.lc-20211111-085347-lc.min.css";
								if(lazycsskeys.indexOf(lazycsskey) === -1) {
									lazycsskeys.push(lazycsskey);
									lazycss.push({
										rel: "stylesheet",
										href: lazycsskey,
										type: "text/css",
										media: "print",
										onload: "this.media='all'"
									});
								}
								</script>
								<div data-component="access" data-component-params="{
            &quot;desktop&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;https://nuevaversion.bbvanet.com.co/loginAEM.html&quot;,
                &quot;height&quot; : &quot;&quot;,
                &quot;target&quot; : &quot;&quot;
            },
            &quot;tablet&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;&quot;,
                &quot;height&quot;: &quot;&quot;,
                &quot;target&quot;: &quot;&quot;
            },
            &quot;mobile&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;&quot;,
                &quot;height&quot;: &quot;&quot;,
                &quot;target&quot;: &quot;&quot;
            }}" data-component-id="af144197-8e53-47c3-96b5-9239341c0894">
									<a class="header__actions__item__link header__actions--menu header__access" accesskey="a" itemprop="url" aria-label="Acceso" href="javascript:void(0)" aria-expanded="false" role="button">
										<svg class="header__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 260" height="24px" width="24px">
											<defs>
												<style>
												.bbvaicn {
													fill: #fff
												}
												</style>
											</defs>
											<path class="bbvaicn" d="M161.38 132.34a70 70 0 0 1-62.76 0A90 90 0 0 0 30 219.77v20h200v-20a90 90 0 0 0-68.62-87.43zM160 209.77h-30v-20h50zm-30-90a50 50 0 1 0-50-50 50 50 0 0 0 50 50z"></path>
										</svg> <span class="header__actions__item__link__text header__access__text--desktop">Acceso</span> <span class="header__actions__item__link__text header__access__text--tablet">Acceso</span> <span class="header__actions__item__link__text header__access__text--mobile">Acceso</span> </a>
								</div>
							</li>
							<li class="header__actions__list header__actions--tablet-hidden">
								<div class="search__trigger" role="search">
									<a href="javascript:void(0);" aria-haspopup="true" aria-controls="access__container__content" aria-label="Buscador" aria-expanded="false" accesskey="s" class="header__actions__item__link search__trigger__btn" title="search">
										<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 260" height="20px" width="20px">
											<defs>
												<style>
												.bbvaicn {
													fill: #fff
												}
												</style>
											</defs>
											<path class="bbvaicn" d="M182.85 162.85a90 90 0 1 0-20 20L220 240l20-20zM150 110a40 40 0 0 0-40-40V50a60 60 0 0 1 60 60z"></path>
										</svg>
									</a>
								</div>
							</li>
							<li class="header__actions__list header__actions--tablet-right">
								<a class="megamenu__trigger header__actions__item__link " href="javascript:void(0);" aria-expanded="false" aria-haspopup="true" aria-label="Menú principal" aria-controls="megamenu__aside" accesskey="m"> <span class="megamenu__trigger megamenu__trigger__open header__actions--menu" aria-hidden="false">
        <span class="header__actions__item__link__text">Menú</span>
									<svg class="header__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 260" height="24px" width="24px">
										<defs>
											<style>
											.bbvaicn {
												fill: #fff
											}
											</style>
										</defs>
										<g>
											<polygon class="bbvaicn" points="210.37 80.12 20.37 80.12 20.37 50.12 240.37 50.12 210.37 80.12"></polygon>
											<polygon class="bbvaicn" points="180.37 145.12 20.37 145.12 20.37 115.12 210.37 115.12 180.37 145.12"></polygon>
											<polygon class="bbvaicn" points="150.37 210.12 20.37 210.12 20.37 180.12 180.37 180.12 150.37 210.12"></polygon>
										</g>
									</svg>
									</span> <span class="megamenu__trigger megamenu__trigger__close hidden header__actions--menu" aria-hidden="true">
        <span class="header__actions__item__link__text">Cerrar</span> <i class="bbva-icon bbva-icon__2_022_close"></i> </span>
								</a>
							</li>
						</ul>
					</nav>
				</div>
			</nav>
			<div class="access__container invisible" id="access__container__content" aria-hidden="true" tabindex="-1">
				<div class="container">
					<div class="access__control">
						<button class="access__close" aria-label="cerrar" tabindex="-1"><i class="bbva-icon bbva-icon__2_022_close"></i></button>
					</div>
					<div class="access__content"> </div>
				</div>
			</div>
		</header>
		<div class="search search--desktop wrapper">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.searchbar/small.lc-20211111-085347-lc.min.ACSHASH0a2280e417756e1a8e1e2b5b1c94886a.css" type="text/css">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.searchbar/large.lc-20211111-085347-lc.min.ACSHASH53d993f0ab9fd1e20813b342ddd6dd7f.css" type="text/css" media="all and (min-width: 600px)">
			<div class="search__base " itemscope="" data-component="search" data-component-params="{&quot;open&quot;: false}" data-search-url="https://bbva-proxy-cloudsearch-sp.appspot.com/v1/cloudsearch/suggest?max=15&amp;site=colombia&amp;access=p&amp;format=os&amp;client=colombia&amp;q=<query>" data-search-query="<query>" aria-hidden="false" data-component-id="5240b8c6-24bb-4b20-92d0-61f221f10e0a" style="visibility: hidden;">
				<div class="container">
					<link itemprop="url" href="https://www.bbva.com.co">
					<div class="container search__bar">
						<form action="/personas/buscador.html" class="search__form" itemprop="potentialAction" itemscope="" itemtype="http://schema.org/SearchAction">
							<meta itemprop="target" content="/personas/buscador.html?_charset_=UTF-8&amp;q={search}">
							<input type="hidden" value="UTF-8" name="_charset_">
							<button type="submit" tabindex="2" class="search__icon-btn" aria-label="Hacer búsqueda"> <i class="bbva-icon bbva-icon__3_001_search"></i> </button>
							<div class="search__label" role="combobox" aria-expanded="false" aria-haspopup="listbox" for="searchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009" aria-owns="listboxsearchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009">
								<label class="search__txt" for="searchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009">Hacer búsqueda, Pulsa enter</label>
								<input tabindex="1" aria-autocomplete="list" autocomplete="off" type="text" name="search" placeholder="Buscar aquí" class="search__input search__input--empty" aria-label="Hacer búsqueda, Pulsa enter" aria-activedescendant="" itemprop="query-input" id="searchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009" aria-controls="listboxsearchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009"> </div> <span class="search__instructional-text">Pulsa enter</span>
							<button class="search__close-btn" tabindex="3" aria-label="Cerrar formulario de búsqueda"> <i class="bbva-icon bbva-icon__2_022_close"></i> </button>
							<input type="submit" value="Search" class="hidden search__hiddeninput" id="buscador_38f3e668-3ad2-4fb1-94e1-2e981d805009"> </form>
						<div class="search__container">
							<div class="search__suggestions"> <span class="search__suggestions__title">Sugerencias</span>
								<ul role="listbox" class="search__suggestions__container" aria-labelledby="searchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009" id="listboxsearchQuery_38f3e668-3ad2-4fb1-94e1-2e981d805009"></ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="wrapper">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenu/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
			<script type="text/javascript" class="lazyCSS">
			if(!lazycss) {
				lazycss = [];
			}
			if(!lazycsskeys) {
				lazycsskeys = [];
			}
			var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenu/large.lc-20211111-085347-lc.min.css";
			if(lazycsskeys.indexOf(lazycsskey) === -1) {
				lazycsskeys.push(lazycsskey);
				lazycss.push({
					rel: "stylesheet",
					href: lazycsskey,
					type: "text/css",
					media: "print",
					onload: "this.media='all'"
				});
			}
			</script>
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.swiper.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.slider.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenucard/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
			<script type="text/javascript" class="lazyCSS">
			if(!lazycss) {
				lazycss = [];
			}
			if(!lazycsskeys) {
				lazycsskeys = [];
			}
			var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenucard/large.lc-20211111-085347-lc.min.css";
			if(lazycsskeys.indexOf(lazycsskey) === -1) {
				lazycsskeys.push(lazycsskey);
				lazycss.push({
					rel: "stylesheet",
					href: lazycsskey,
					type: "text/css",
					media: "print",
					onload: "this.media='all'"
				});
			}
			</script>
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.accordion/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
			<script type="text/javascript" class="lazyCSS">
			if(!lazycss) {
				lazycss = [];
			}
			if(!lazycsskeys) {
				lazycsskeys = [];
			}
			var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.accordion/large.lc-20211111-085347-lc.min.css";
			if(lazycsskeys.indexOf(lazycsskey) === -1) {
				lazycsskeys.push(lazycsskey);
				lazycss.push({
					rel: "stylesheet",
					href: lazycsskey,
					type: "text/css",
					media: "print",
					onload: "this.media='all'"
				});
			}
			</script>
			<aside class="animations__menu megamenu__container hidden" id="megamenu__aside" aria-hidden="true" data-component="megamenu" itemscope="" itemtype="http://www.schema.org/SiteNavigationElement" data-component-id="814a97eb-8a9c-4137-a4fe-9016365b7d5d">
				<div class="megamenu__fixed">
					<div class="megamenu__navigation__container">
						<div class="megamenu__navigation accordion--mobile" itemscope="" itemtype="http://www.schema.org/SiteNavigationElement">
							<div class="megamenu__flyout--nonmobile">
								<nav class="megamenu__flyout ">
									<div itemprop="name" class="megamenu__flyout__title">Productos</div>
									<a class="megamenu__navigation__home" href="/personas.html" tabindex="-1"> <i aria-hidden="true" class="bbva-icon bbva-icon__3_002_home"></i>Inicio </a>
									<ul class="megamenu__flyout__list" itemscope="" itemtype="http://schema.org/ListItem" role="list">
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="8c0e1d1c-ca08-469c-8c3a-5d9e8415f65e">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="cuentas" href="/personas/productos/cuentas.html" aria-controls="flyout_secondary_65ee5bbe-a6cf-40fd-9447-6dc3c802593a" id="flyout_primary_8d7ef5bb-d7e9-47f8-906b-715fd865e9d7"> <span itemprop="name" class="megamenu__navigation__text">Cuentas</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="cuentas" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_65ee5bbe-a6cf-40fd-9447-6dc3c802593a" aria-labelledby="flyout_primary_8d7ef5bb-d7e9-47f8-906b-715fd865e9d7">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/cuentas.html" tabindex="-1"> <span itemprop="name">Cuentas</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/en-linea.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuenta en Línea</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/nomina.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas de Nómina</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/cuentas/nomina/pensionados.html" tabindex="-1"> <span itemprop="item name">Cuenta de Nómina para Pensionados</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/ahorro.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas de Ahorro</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/corriente.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Corrientes</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/portafolios.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Portafolios</span> </a>
													</div>
													<ul class="megamenu__flyout__linkwithicon">
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/cuentas.html" tabindex="-1"> <span itemprop="item name">cuentas</span> </a>
														</li>
													</ul>
												</div>
											</div>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="02242833-d903-4f8b-a8bd-25ceb0319f7e">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="tarjetas" href="/personas/productos/tarjetas.html" aria-controls="flyout_secondary_f3989951-60d3-46ed-abc8-3c084f1694fc" id="flyout_primary_a60ec4f2-5d8c-47ef-8ff5-cf7489ae24b6"> <span itemprop="name" class="megamenu__navigation__text">Tarjetas</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="tarjetas" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_f3989951-60d3-46ed-abc8-3c084f1694fc" aria-labelledby="flyout_primary_a60ec4f2-5d8c-47ef-8ff5-cf7489ae24b6">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/tarjetas.html" tabindex="-1"> <span itemprop="name">Tarjetas</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/credito.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas de Crédito</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/visa.html" tabindex="-1"> <span itemprop="item name">Tarjetas Visa</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/mastercard.html" tabindex="-1"> <span itemprop="item name">Tarjetas Mastercard</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/amparada.html" tabindex="-1"> <span itemprop="item name">Tarjeta Amparada</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/debito.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjeta Débito</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/puntos-y-promociones.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Puntos y promociones</span> </a>
													</div>
													<ul class="megamenu__flyout__linkwithicon">
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/pago-con-puntos.html" tabindex="-1"> <span itemprop="item name">Pago con puntos</span> </a>
														</li>
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/avances.html" tabindex="-1"> <span itemprop="item name">Avances</span> </a>
														</li>
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/beneficios.html" tabindex="-1"> <span itemprop="item name">Beneficios</span> </a>
														</li>
													</ul>
												</div>
											</div>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="6aab4b96-ca87-450c-9421-b941d7ef7c7c">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="prestamos" href="/personas/productos/prestamos.html" aria-controls="flyout_secondary_2670b704-cb6d-4653-83e2-c4cba87f6fcc" id="flyout_primary_d9e45883-8434-4fd7-a1dd-32cbd394365f"> <span itemprop="name" class="megamenu__navigation__text">Préstamos</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="prestamos" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_2670b704-cb6d-4653-83e2-c4cba87f6fcc" aria-labelledby="flyout_primary_d9e45883-8434-4fd7-a1dd-32cbd394365f">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/prestamos.html" tabindex="-1"> <span itemprop="name">Préstamos</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/online.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Préstamos en Línea</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/vivienda.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Créditos de Vivienda</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/hipotecario.html" tabindex="-1"> <span itemprop="item name">Crédito Hipotecario</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/hipotecario-sostenible.html" tabindex="-1"> <span itemprop="item name">Crédito Vivienda Sostenible</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/leasing-habitacional.html" tabindex="-1"> <span itemprop="item name">Leasing Habitacional</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/leasing-habitacional-sostenible.html" tabindex="-1"> <span itemprop="item name">Leasing Habitacional Sostenible</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/remodelacion-leasing.html" tabindex="-1"> <span itemprop="item name">Remodelacion Leasing Habitacional</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/cesion-de-cartera.html" tabindex="-1"> <span itemprop="item name">Cesión Hipotecaria</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/remodelacion.html" tabindex="-1"> <span itemprop="item name">Remodelación</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/subrogacion.html" tabindex="-1"> <span itemprop="item name">Proyectos financiados</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/construccion-de-vivienda.html" tabindex="-1"> <span itemprop="item name">Constructor Individual</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/consumo.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Créditos de Consumo</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/cupo-rotativo.html" tabindex="-1"> <span itemprop="item name">Crédito Cupo Rotativo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/libre-inversion.html" tabindex="-1"> <span itemprop="item name">Crédito Libre Inversión</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/compra-de-cartera.html" tabindex="-1"> <span itemprop="item name">Compra de Cartera</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/educacion.html" tabindex="-1"> <span itemprop="item name">Crédito Educativo </span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/libranza.html" tabindex="-1"> <span itemprop="item name">Crédito de Libranza</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/vehiculo.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Crédito de Vehículo</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/nuevo-o-usado.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículo Nuevo o Usado</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/compra-de-cartera-vehiculo.html" tabindex="-1"> <span itemprop="item name">Compra de Cartera de Vehículo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/productivos.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículo ProductIvo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/planes-financieros.html" tabindex="-1"> <span itemprop="item name">Planes financieros</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/mi-papa-copiloto.html" tabindex="-1"> <span itemprop="item name">Crédito Mi papá mi copiloto</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/motocicleta-nueva-usada.html" tabindex="-1"> <span itemprop="item name">Crédito para Moto Nueva o Usada</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/leasing.html" tabindex="-1"> <span itemprop="item name"> Leasing de Vehículo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/vehiculos-hibridos-y-electricos.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículos Híbridos o Eléctricos </span> </a>
															</li>
														</ul>
													</div>
													<ul class="megamenu__flyout__linkwithicon">
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/servicios-digitales/adelanto-de-nomina.html" tabindex="-1"> <span itemprop="item name">Adelanto de Nómina</span> </a>
														</li>
													</ul>
												</div>
											</div>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="f4427832-e309-4eb6-95ad-fc4cec42e080">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="inversion" href="/personas/productos/inversion.html" aria-controls="flyout_secondary_99e703c2-9102-4147-8194-a3c6803f96d3" id="flyout_primary_1244f0cb-67ad-4c2e-a9da-41f5cab10663"> <span itemprop="name" class="megamenu__navigation__text">Inversiones</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="inversion" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_99e703c2-9102-4147-8194-a3c6803f96d3" aria-labelledby="flyout_primary_1244f0cb-67ad-4c2e-a9da-41f5cab10663">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/inversion.html" tabindex="-1"> <span itemprop="name">Inversiones</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/inversion/cdt.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">CDT</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/online.html" tabindex="-1"> <span itemprop="item name">CDT Online</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/tradicional.html" tabindex="-1"> <span itemprop="item name">CDT Tradicionales</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/largo-plazo.html" tabindex="-1"> <span itemprop="item name">CDT Largo Plazo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/tasa-variable-dtf.html" tabindex="-1"> <span itemprop="item name">CDT Tasa Variable</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/inversion/fondos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Fondos de Inversión </span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/digital.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Digital</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/paramo.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Páramo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/efectivo.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Efectivo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/pais.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA País</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/fam.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA FAM</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/plazo-30.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Plazo 30</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/balanceado-global.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión Balanceado Global</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/balanceado-gaia.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión Balanceado Gaia</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</li>
										<li class="megamenu__navigation__list__item">
											<a tabindex="-1" class="megamenu__navigation__link accordion--nosubmenu" href="/personas/productos/pensionados.html"> <span itemprop="name" class="megamenu__navigation__text">Pensionados</span> </a>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="4669fec3-923c-4503-ac92-1d9a53a948f5">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="seguros" href="/personas/productos/seguros.html" aria-controls="flyout_secondary_d9f8ee63-99d6-4dce-938a-14c18350c5a2" id="flyout_primary_4190f24d-755b-4d26-80ab-e04edd81fc2a"> <span itemprop="name" class="megamenu__navigation__text">Seguros</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="seguros" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_d9f8ee63-99d6-4dce-938a-14c18350c5a2" aria-labelledby="flyout_primary_4190f24d-755b-4d26-80ab-e04edd81fc2a">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/seguros.html" tabindex="-1"> <span itemprop="name">Seguros</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/seguros/libres.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Libres</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/soat.html" tabindex="-1"> <span itemprop="item name">SOAT Virtual</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/oncologico.html" tabindex="-1"> <span itemprop="item name">Seguro Oncológico</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/familia-vital.html" tabindex="-1"> <span itemprop="item name">Seguro de Familia Vital</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hogar-y-contenidos.html" tabindex="-1"> <span itemprop="item name">Seguro Hogar y Contenidos</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/autos.html" tabindex="-1"> <span itemprop="item name">Seguro de Autos</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hurto-de-tarjeta.html" tabindex="-1"> <span itemprop="item name">Seguro de Hurto de Tarjeta</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/accidentes-personales-salud.html" tabindex="-1"> <span itemprop="item name">Seguro de Accidentes Personales Salud</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hurto-atm.html" tabindex="-1"> <span itemprop="item name">Seguro de Hurto ATM</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/multiriesgo-hogar.html" tabindex="-1"> <span itemprop="item name">Seguro Multiriesgo para Hogar</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/vida-individual.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Indivual</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hogar-individual.html" tabindex="-1"> <span itemprop="item name"> Seguro de Hogar Individual</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/cuota-segura-trabajadores-dependientes.html" tabindex="-1"> <span itemprop="item name">Seguro Cuota Segura Trabajadores Dependientes</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/cuota-segura-trabajadores-independientes.html" tabindex="-1"> <span itemprop="item name">Seguro Cuota Segura Trabajadores Independientes</span> </a>
															</li>
														</ul>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/seguros/deudores.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Deudores</span> </a>
														<ul>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vida.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Colectivo</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vehiculos.html" tabindex="-1"> <span itemprop="item name">Seguro de Vehículos</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/tarjeta-de-credito.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida para Tarjetas de Crédito</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/seguro-de-vida-consumo-desembolsado.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Consumo Desembolsado </span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/incendio-y-terremoto.html" tabindex="-1"> <span itemprop="item name">Seguro de incendio y terremoto para créditos hipotecario y/o leasing habitacional</span> </a>
															</li>
															<li>
																<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vida-colectivo.html" tabindex="-1"> <span itemprop="item name">Seguro Vida Colectivo Crédito Hipotecario y/o Leasing Habitacional</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</div>
										</li>
										<li class="megamenu__navigation__list__item">
											<a tabindex="-1" class="megamenu__navigation__link accordion--nosubmenu" href="/personas/productos/divisas.html"> <span itemprop="name" class="megamenu__navigation__text">Divisas</span> </a>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="3bb0ead5-42cb-4c93-832e-310b929d6143">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="banca-personal" href="/personas/productos/banca-personal.html" aria-controls="flyout_secondary_f5a4e54a-620c-4826-86a6-86bebdd99fb9" id="flyout_primary_9f8a5b49-857d-461d-949f-bc0a5cdba325"> <span itemprop="name" class="megamenu__navigation__text">Banca Personal</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="banca-personal" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_f5a4e54a-620c-4826-86a6-86bebdd99fb9" aria-labelledby="flyout_primary_9f8a5b49-857d-461d-949f-bc0a5cdba325">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/banca-personal.html" tabindex="-1"> <span itemprop="name">Banca Personal</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/inversion.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Inversión Banca Personal</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/cuentas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Banca Personal</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/tarjetas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas Banca Personal</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/prestamos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Préstamos Banca Personal</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/seguros.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Banca Personal</span> </a>
													</div>
												</div>
											</div>
										</li>
										<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" class="megamenu__navigation__list__item" data-component-id="3353dc38-a62c-45af-8f56-8d3691dbcffb">
											<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="premium" href="/personas/productos/premium.html" aria-controls="flyout_secondary_211a2a47-3b8b-4312-8599-e70affb7261e" id="flyout_primary_751f5245-c420-4e30-a55f-a9541b39aeae"> <span itemprop="name" class="megamenu__navigation__text">Premium</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
											<div class="megamenu__flyout__secondary accordion__list" data-menu-name="premium" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_211a2a47-3b8b-4312-8599-e70affb7261e" aria-labelledby="flyout_primary_751f5245-c420-4e30-a55f-a9541b39aeae">
												<div class="accordion__list__content">
													<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/premium.html" tabindex="-1"> <span itemprop="name">Premium</span> </a>
													<div class="accordion__list__content--haschilden">
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/inversion.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Inversión Premium</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/cuentas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Premium</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/tarjetas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas Premium</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/prestamos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Financiación Premium</span> </a>
														<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/seguros.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Premium</span> </a>
													</div>
													<ul class="megamenu__flyout__linkwithicon">
														<li>
															<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/premium/soluciones-no-financieras.html" tabindex="-1"> <span itemprop="item name">Soluciones No Financieras</span> </a>
														</li>
													</ul>
												</div>
											</div>
										</li>
										<li class="megamenu__navigation__list__item">
											<a tabindex="-1" class="megamenu__navigation__link accordion__list__item__heading" href="/personas/productos/banca-privada.html"> <span itemprop="name" class="megamenu__navigation__text">Banca privada</span> </a>
										</li>
									</ul>
									<div class="megamenu__flyout__linkwithicon" itemscope="" itemtype="http://schema.org/Service">
										<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.linkwithicon.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" href="/personas/servicios-digitales.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/2_042_nearme.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Servicios digitales</span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_659572967" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="enlace a blog bbva" aria-label="enlace a blog bbva" href="/personas/blog.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/4_024_quotemark.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Blog </span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1221498243" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="enlace a beneficios" aria-label="enlace a beneficios" href="/personas/productos/tarjetas-de-credito/beneficios.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/5_016_point.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Beneficios BBVA</span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1583636697" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="Atención al cliente" aria-label="Atención al cliente" href="/personas/atencion-al-cliente.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_003_myprofile.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Atención al cliente</span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1281190392" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_blank" rel="noopener noreferrer" title="enlace a oficinas y cajeros. Abre en nueva ventana" aria-label="enlace a oficinas y cajeros. Abre en nueva ventana" href="/personas/oficinas.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_026_mobile.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Oficinas y cajeros</span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_379865119" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" href="/personas/preguntas-frecuentes.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/4_003_help.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Preguntas Frecuentes</span> </span>
										</a>
										<br>
										<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1691019573" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " href="https://www.bbva.com/es/co/?utm_source=bbvacol&amp;utm_campaign=modulo_col" target="_blank" rel="noopener noreferrer" title="Newsroom BBVA. Abre en nueva ventana" aria-label="Newsroom BBVA. Abre en nueva ventana" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/1_028_international.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Newsroom BBVA</span> </span>
										</a>
										<br> </div>
								</nav>
							</div>
							<div class="mainnavigation--mobile" itemscope="" itemtype="https://schema.org/SiteNavigationElement">
								<div class="mainnavigation__base">
									<nav class="mainnavigation__list" role="navigation"> <a class="mainnavigation__item mainnavigation--active" aria-label="Personas" href="/" tabindex="-1">
            Personas
        </a> <a class="mainnavigation__item " aria-label="Empresas" href="/empresas.html" tabindex="-1">
            Empresas
        </a> </nav>
									<nav class="megamenu__flyout">
										<ul class="megamenu__flyout__list" role="list" itemscope="" itemtype="http://schema.org/ListItem">
											<li>
												<a class="megamenu__navigation__home" href="/personas.html" tabindex="-1"> <i aria-hidden="true" class="bbva-icon bbva-icon__3_002_home"></i>Inicio </a>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="edb51051-55ef-4d44-ab80-ef2ede2ca7ab">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="cuentas" href="/personas/productos/cuentas.html" aria-controls="flyout_secondary_b7b3789f-75f0-4c77-a1a4-2900bc099bff" id="flyout_primary_aac2bb25-c113-4efd-86bb-3abea3f01e31"> <span itemprop="name" class="megamenu__navigation__text">Cuentas</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="cuentas" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_b7b3789f-75f0-4c77-a1a4-2900bc099bff" aria-labelledby="flyout_primary_aac2bb25-c113-4efd-86bb-3abea3f01e31">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/cuentas.html" tabindex="-1"> <span itemprop="name">Cuentas</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/en-linea.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuenta en Línea</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/nomina.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas de Nómina</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/cuentas/nomina/pensionados.html" tabindex="-1"> <span itemprop="item name">Cuenta de Nómina para Pensionados</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/ahorro.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas de Ahorro</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/corriente.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Corrientes</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/cuentas/portafolios.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Portafolios</span> </a>
														</div>
														<ul class="megamenu__flyout__linkwithicon">
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/cuentas.html" tabindex="-1"> <span itemprop="item name">cuentas</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="e13ab39e-7d79-40bf-8966-32c935f534f7">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="tarjetas" href="/personas/productos/tarjetas.html" aria-controls="flyout_secondary_97c3dc0c-c0d3-4757-98d3-5ff18e9b4db4" id="flyout_primary_7f6701ff-b328-4bce-a9a0-eb5c8513d046"> <span itemprop="name" class="megamenu__navigation__text">Tarjetas</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="tarjetas" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_97c3dc0c-c0d3-4757-98d3-5ff18e9b4db4" aria-labelledby="flyout_primary_7f6701ff-b328-4bce-a9a0-eb5c8513d046">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/tarjetas.html" tabindex="-1"> <span itemprop="name">Tarjetas</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/credito.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas de Crédito</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/visa.html" tabindex="-1"> <span itemprop="item name">Tarjetas Visa</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/mastercard.html" tabindex="-1"> <span itemprop="item name">Tarjetas Mastercard</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/amparada.html" tabindex="-1"> <span itemprop="item name">Tarjeta Amparada</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/debito.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjeta Débito</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/tarjetas/puntos-y-promociones.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Puntos y promociones</span> </a>
														</div>
														<ul class="megamenu__flyout__linkwithicon">
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/pago-con-puntos.html" tabindex="-1"> <span itemprop="item name">Pago con puntos</span> </a>
															</li>
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/credito/avances.html" tabindex="-1"> <span itemprop="item name">Avances</span> </a>
															</li>
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/tarjetas/beneficios.html" tabindex="-1"> <span itemprop="item name">Beneficios</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="5dfd7fe9-0725-4598-8f04-2f0a6deec5f1">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="prestamos" href="/personas/productos/prestamos.html" aria-controls="flyout_secondary_74ac0975-13b4-4c0d-a8ce-d726f656bfbe" id="flyout_primary_6417c843-94e8-49c0-90e2-8f87a7be4148"> <span itemprop="name" class="megamenu__navigation__text">Préstamos</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="prestamos" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_74ac0975-13b4-4c0d-a8ce-d726f656bfbe" aria-labelledby="flyout_primary_6417c843-94e8-49c0-90e2-8f87a7be4148">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/prestamos.html" tabindex="-1"> <span itemprop="name">Préstamos</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/online.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Préstamos en Línea</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/vivienda.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Créditos de Vivienda</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/hipotecario.html" tabindex="-1"> <span itemprop="item name">Crédito Hipotecario</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/hipotecario-sostenible.html" tabindex="-1"> <span itemprop="item name">Crédito Vivienda Sostenible</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/leasing-habitacional.html" tabindex="-1"> <span itemprop="item name">Leasing Habitacional</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/leasing-habitacional-sostenible.html" tabindex="-1"> <span itemprop="item name">Leasing Habitacional Sostenible</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/remodelacion-leasing.html" tabindex="-1"> <span itemprop="item name">Remodelacion Leasing Habitacional</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/cesion-de-cartera.html" tabindex="-1"> <span itemprop="item name">Cesión Hipotecaria</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/remodelacion.html" tabindex="-1"> <span itemprop="item name">Remodelación</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/subrogacion.html" tabindex="-1"> <span itemprop="item name">Proyectos financiados</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vivienda/construccion-de-vivienda.html" tabindex="-1"> <span itemprop="item name">Constructor Individual</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/consumo.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Créditos de Consumo</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/cupo-rotativo.html" tabindex="-1"> <span itemprop="item name">Crédito Cupo Rotativo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/libre-inversion.html" tabindex="-1"> <span itemprop="item name">Crédito Libre Inversión</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/compra-de-cartera.html" tabindex="-1"> <span itemprop="item name">Compra de Cartera</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/educacion.html" tabindex="-1"> <span itemprop="item name">Crédito Educativo </span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/consumo/libranza.html" tabindex="-1"> <span itemprop="item name">Crédito de Libranza</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/prestamos/vehiculo.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Crédito de Vehículo</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/nuevo-o-usado.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículo Nuevo o Usado</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/compra-de-cartera-vehiculo.html" tabindex="-1"> <span itemprop="item name">Compra de Cartera de Vehículo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/productivos.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículo ProductIvo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/planes-financieros.html" tabindex="-1"> <span itemprop="item name">Planes financieros</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/mi-papa-copiloto.html" tabindex="-1"> <span itemprop="item name">Crédito Mi papá mi copiloto</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/motocicleta-nueva-usada.html" tabindex="-1"> <span itemprop="item name">Crédito para Moto Nueva o Usada</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/leasing.html" tabindex="-1"> <span itemprop="item name"> Leasing de Vehículo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/prestamos/vehiculo/vehiculos-hibridos-y-electricos.html" tabindex="-1"> <span itemprop="item name">Crédito de Vehículos Híbridos o Eléctricos </span> </a>
																</li>
															</ul>
														</div>
														<ul class="megamenu__flyout__linkwithicon">
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/servicios-digitales/adelanto-de-nomina.html" tabindex="-1"> <span itemprop="item name">Adelanto de Nómina</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="95135183-a89e-4260-a442-8cc4bb4a6080">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="inversion" href="/personas/productos/inversion.html" aria-controls="flyout_secondary_3bcf84a0-e9c6-4901-9b0d-81846af69886" id="flyout_primary_24695ad1-231f-4789-99b5-e7b63930e7e2"> <span itemprop="name" class="megamenu__navigation__text">Inversiones</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="inversion" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_3bcf84a0-e9c6-4901-9b0d-81846af69886" aria-labelledby="flyout_primary_24695ad1-231f-4789-99b5-e7b63930e7e2">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/inversion.html" tabindex="-1"> <span itemprop="name">Inversiones</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/inversion/cdt.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">CDT</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/online.html" tabindex="-1"> <span itemprop="item name">CDT Online</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/tradicional.html" tabindex="-1"> <span itemprop="item name">CDT Tradicionales</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/largo-plazo.html" tabindex="-1"> <span itemprop="item name">CDT Largo Plazo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/cdt/tasa-variable-dtf.html" tabindex="-1"> <span itemprop="item name">CDT Tasa Variable</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/inversion/fondos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Fondos de Inversión </span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/digital.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Digital</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/paramo.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Páramo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/efectivo.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Efectivo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/pais.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA País</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/fam.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA FAM</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/plazo-30.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión BBVA Plazo 30</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/balanceado-global.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión Balanceado Global</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/inversion/fondos/balanceado-gaia.html" tabindex="-1"> <span itemprop="item name">Fondo de Inversión Balanceado Gaia</span> </a>
																</li>
															</ul>
														</div>
													</div>
												</div>
											</li>
											<li>
												<a tabindex="-1" class="megamenu__navigation__link accordion--nosubmenu" href="/personas/productos/pensionados.html"> <span itemprop="name">Pensionados</span> </a>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="473311f6-40ce-4727-ac15-7a0aac98c322">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="seguros" href="/personas/productos/seguros.html" aria-controls="flyout_secondary_1cc762e3-ebcd-4135-ab35-88ddbbdaccf2" id="flyout_primary_076942be-3222-4d46-a8f8-683611bdd526"> <span itemprop="name" class="megamenu__navigation__text">Seguros</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="seguros" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_1cc762e3-ebcd-4135-ab35-88ddbbdaccf2" aria-labelledby="flyout_primary_076942be-3222-4d46-a8f8-683611bdd526">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/seguros.html" tabindex="-1"> <span itemprop="name">Seguros</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/seguros/libres.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Libres</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/soat.html" tabindex="-1"> <span itemprop="item name">SOAT Virtual</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/oncologico.html" tabindex="-1"> <span itemprop="item name">Seguro Oncológico</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/familia-vital.html" tabindex="-1"> <span itemprop="item name">Seguro de Familia Vital</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hogar-y-contenidos.html" tabindex="-1"> <span itemprop="item name">Seguro Hogar y Contenidos</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/autos.html" tabindex="-1"> <span itemprop="item name">Seguro de Autos</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hurto-de-tarjeta.html" tabindex="-1"> <span itemprop="item name">Seguro de Hurto de Tarjeta</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/accidentes-personales-salud.html" tabindex="-1"> <span itemprop="item name">Seguro de Accidentes Personales Salud</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hurto-atm.html" tabindex="-1"> <span itemprop="item name">Seguro de Hurto ATM</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/multiriesgo-hogar.html" tabindex="-1"> <span itemprop="item name">Seguro Multiriesgo para Hogar</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/vida-individual.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Indivual</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/hogar-individual.html" tabindex="-1"> <span itemprop="item name"> Seguro de Hogar Individual</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/cuota-segura-trabajadores-dependientes.html" tabindex="-1"> <span itemprop="item name">Seguro Cuota Segura Trabajadores Dependientes</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/libres/cuota-segura-trabajadores-independientes.html" tabindex="-1"> <span itemprop="item name">Seguro Cuota Segura Trabajadores Independientes</span> </a>
																</li>
															</ul>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/seguros/deudores.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Deudores</span> </a>
															<ul>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vida.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Colectivo</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vehiculos.html" tabindex="-1"> <span itemprop="item name">Seguro de Vehículos</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/tarjeta-de-credito.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida para Tarjetas de Crédito</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/seguro-de-vida-consumo-desembolsado.html" tabindex="-1"> <span itemprop="item name">Seguro de Vida Consumo Desembolsado </span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/incendio-y-terremoto.html" tabindex="-1"> <span itemprop="item name">Seguro de incendio y terremoto para créditos hipotecario y/o leasing habitacional</span> </a>
																</li>
																<li>
																	<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/seguros/deudores/vida-colectivo.html" tabindex="-1"> <span itemprop="item name">Seguro Vida Colectivo Crédito Hipotecario y/o Leasing Habitacional</span> </a>
																</li>
															</ul>
														</div>
													</div>
												</div>
											</li>
											<li>
												<a tabindex="-1" class="megamenu__navigation__link accordion--nosubmenu" href="/personas/productos/divisas.html"> <span itemprop="name">Divisas</span> </a>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="b4606088-a09e-42fd-9c86-7b008c7e636d">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="banca-personal" href="/personas/productos/banca-personal.html" aria-controls="flyout_secondary_cf16c280-41ab-47c1-895d-51bdc8db5414" id="flyout_primary_38c556dd-6d36-4ed7-892f-2f2ef18caf72"> <span itemprop="name" class="megamenu__navigation__text">Banca Personal</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="banca-personal" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_cf16c280-41ab-47c1-895d-51bdc8db5414" aria-labelledby="flyout_primary_38c556dd-6d36-4ed7-892f-2f2ef18caf72">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/banca-personal.html" tabindex="-1"> <span itemprop="name">Banca Personal</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/inversion.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Inversión Banca Personal</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/cuentas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Banca Personal</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/tarjetas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas Banca Personal</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/prestamos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Préstamos Banca Personal</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/banca-personal/seguros.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Banca Personal</span> </a>
														</div>
													</div>
												</div>
											</li>
											<li data-component="accordion" role="listitem" data-component-params="{&quot;route&quot;: false, &quot;viewport&quot;:[&quot;tablet&quot;, &quot;mobile&quot;]}" data-component-id="5b132249-6d0d-44b0-8a42-ac24e501b9cb">
												<a data-accordion-toogle="" tabindex="-1" role="button" aria-expanded="false" class="megamenu__navigation__link megamenu__navigation__primary accordion__list__item__heading" data-menu-expand="premium" href="/personas/productos/premium.html" aria-controls="flyout_secondary_7919bba6-9b05-4293-8d80-1ccf7b3c68f1" id="flyout_primary_fb112793-6e9b-4377-984b-8b6a214d2cdc"> <span itemprop="name" class="megamenu__navigation__text">Premium</span> <i aria-hidden="true" class="accordion--icon bbva-icon bbva-icon__2_017_forward"></i> </a>
												<div class="megamenu__flyout__secondary accordion__list" data-menu-name="premium" aria-expanded="false" aria-hidden="true" data-accordion-content="" id="flyout_secondary_7919bba6-9b05-4293-8d80-1ccf7b3c68f1" aria-labelledby="flyout_primary_fb112793-6e9b-4377-984b-8b6a214d2cdc">
													<div class="accordion__list__content">
														<a itemprop="url" class="megamenu__navigation__link megamenu__flyout__categorySelected" href="/personas/productos/premium.html" tabindex="-1"> <span itemprop="name">Premium</span> </a>
														<div class="accordion__list__content--haschilden">
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/inversion.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Inversión Premium</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/cuentas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Cuentas Premium</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/tarjetas.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Tarjetas Premium</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/prestamos.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Financiación Premium</span> </a>
															<a class="megamenu__navigation__highlight megamenu__flyout__subcategory" href="/personas/productos/premium/seguros.html" tabindex="-1"> <span class="megamenu__navigation__title" itemprop="name">Seguros Premium</span> </a>
														</div>
														<ul class="megamenu__flyout__linkwithicon">
															<li>
																<a itemprop="url" target="_self" class="megamenu__navigation__link megamenu__flyout__template" href="/personas/productos/premium/soluciones-no-financieras.html" tabindex="-1"> <span itemprop="item name">Soluciones No Financieras</span> </a>
															</li>
														</ul>
													</div>
												</div>
											</li>
											<li>
												<a tabindex="-1" class="megamenu__navigation__link accordion__list__item__heading" href="/personas/productos/banca-privada.html"> <span itemprop="name">Banca privada</span> </a>
											</li>
										</ul>
									</nav>
								</div>
							</div>
						</div>
						<div class="search search--mobile">
							<div class="search__base " itemscope="" data-component="search" data-component-params="{&quot;open&quot;: false}" data-search-url="https://bbva-proxy-cloudsearch-sp.appspot.com/v1/cloudsearch/suggest?max=15&amp;site=colombia&amp;access=p&amp;format=os&amp;client=colombia&amp;q=<query>" data-search-query="<query>" aria-hidden="false" data-component-id="a072ccb0-561d-4265-8639-c5d9cfed1fd3" style="visibility: hidden;">
								<div class="container">
									<link>
									<div class="container search__bar">
										<form action="/personas/buscador.html" class="search__form" itemprop="potentialAction" itemscope="" itemtype="http://schema.org/SearchAction">
											<meta itemprop="target" content="/personas/buscador.html?_charset_=UTF-8&amp;q={search}">
											<input type="hidden" value="UTF-8" name="_charset_">
											<button type="submit" tabindex="2" class="search__icon-btn" aria-label="Hacer búsqueda"> <i class="bbva-icon bbva-icon__3_001_search"></i> </button>
											<div class="search__label" role="combobox" aria-expanded="false" aria-haspopup="listbox" for="searchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c" aria-owns="listboxsearchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c">
												<label class="search__txt" for="searchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c">Hacer búsqueda, Pulsa enter</label>
												<input tabindex="1" aria-autocomplete="list" autocomplete="off" type="text" name="search" placeholder="Buscar aquí" class="search__input search__input--empty" aria-label="Hacer búsqueda, Pulsa enter" aria-activedescendant="" itemprop="query-input" id="searchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c" aria-controls="listboxsearchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c"> </div> <span class="search__instructional-text">Pulsa enter</span>
											<button class="search__close-btn" tabindex="3" aria-label="Cerrar formulario de búsqueda"> <i class="bbva-icon bbva-icon__2_022_close"></i> </button>
											<input type="submit" value="Search" class="hidden search__hiddeninput" id="buscador_e522d50f-50c1-4613-a4f5-7b596b3f5d5c"> </form>
										<div class="search__container">
											<div class="search__suggestions"> <span class="search__suggestions__title">Sugerencias</span>
												<ul role="listbox" class="search__suggestions__container" aria-labelledby="searchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c" id="listboxsearchQuery_e522d50f-50c1-4613-a4f5-7b596b3f5d5c"></ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="megamenu__cards container megamenu__cards--compact" itemscope="" itemtype="http://schema.org/Service" data-component="megamenucards" data-component-id="8f9e6935-84af-4c4f-822d-f3fd74cfd896">
						<p class="megamenu__cards__title">Oportunidades</p>
						<div class="megamenu__cards__container">
							<div class="swiper-button-prev megamenu--preventfocus" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="false"> <i class="bbva-icon bbva-icon__2_046_back"></i> </div>
							<div class="container swiper-container swiper-container-initialized swiper-container-horizontal">
								<ul class="megamenu__cardlist swiper-wrapper" itemprop="hasOfferCatalog" itemscope="" itemtype="http://schema.org/OfferCatalog" style="transition-duration: 0ms;">
									<li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/OfferCatalog" class="megamenu__card swiper-slide">
										<a class="megamenu__card__link hidden" itemprop="url" tabindex="-1" href="/personas/oportunidades/tu-dia-a-dia.html">
											<div class="megamenu__card__base">
												<div class="megamenu__card__header"> <img sizes="(min-width: 990px) 25vw, (min-width: 600px) 50vw, 100vw" data-component="lazyimages" data-component-params="{&quot;keepSize&quot;: &quot;&quot;, &quot;aspectRatio&quot;: &quot;&quot;}" data-src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/send_money_app_dollar.svg" itemprop="image" class="megamenu__card__image" alt="" data-component-id="4a600632-d9c9-4df0-9a6d-9f742c40a120">
													<p role="presentation" class="megamenu__card__title">Productos para todos los días </p>
												</div>
												<p itemprop="description" class="megamenu__card__text rte">Gestiona tus tarjetas, cuentas o realiza pagos.</p>
											</div>
										</a>
									</li>
									<li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/OfferCatalog" class="megamenu__card swiper-slide">
										<a class="megamenu__card__link hidden" itemprop="url" tabindex="-1" href="/personas/oportunidades/cumple-tus-suenos.html">
											<div class="megamenu__card__base">
												<div class="megamenu__card__header"> <img sizes="(min-width: 990px) 25vw, (min-width: 600px) 50vw, 100vw" data-component="lazyimages" data-component-params="{&quot;keepSize&quot;: &quot;&quot;, &quot;aspectRatio&quot;: &quot;&quot;}" data-src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/plane.svg" itemprop="image" class="megamenu__card__image" alt="" data-component-id="5c4705f5-a597-4207-9354-5e81b23f8333">
													<p role="presentation" class="megamenu__card__title">Cumple tus sueños </p>
												</div>
												<p itemprop="description" class="megamenu__card__text rte">Viaja, estudia y compra el carro que siempre has querido.</p>
											</div>
										</a>
									</li>
									<li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/OfferCatalog" class="megamenu__card swiper-slide">
										<a class="megamenu__card__link hidden" itemprop="url" tabindex="-1" href="/personas/oportunidades/crece-en-familia.html">
											<div class="megamenu__card__base">
												<div class="megamenu__card__header"> <img sizes="(min-width: 990px) 25vw, (min-width: 600px) 50vw, 100vw" data-component="lazyimages" data-component-params="{&quot;keepSize&quot;: &quot;&quot;, &quot;aspectRatio&quot;: &quot;&quot;}" data-src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/mortgage.svg" itemprop="image" class="megamenu__card__image" alt="" data-component-id="ba4f59ec-6156-4c56-8e97-b298c60c84f4">
													<p role="presentation" class="megamenu__card__title">Crece en familia </p>
												</div>
												<p itemprop="description" class="megamenu__card__text rte">Asegura tu hogar, obtén tu crédito de vivienda y haz realidad tus proyectos.</p>
											</div>
										</a>
									</li>
									<li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/OfferCatalog" class="megamenu__card swiper-slide">
										<a class="megamenu__card__link hidden" itemprop="url" tabindex="-1" href="/personas/oportunidades/ahorra-e-invierte.html">
											<div class="megamenu__card__base">
												<div class="megamenu__card__header"> <img sizes="(min-width: 990px) 25vw, (min-width: 600px) 50vw, 100vw" data-component="lazyimages" data-component-params="{&quot;keepSize&quot;: &quot;&quot;, &quot;aspectRatio&quot;: &quot;&quot;}" data-src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/bulb.svg" itemprop="image" class="megamenu__card__image" alt="" data-component-id="5e50bbca-1f88-4c6d-9cb0-e4f7c072e5f9">
													<p role="presentation" class="megamenu__card__title">Ahorra e invierte</p>
												</div>
												<p itemprop="description" class="megamenu__card__text rte">Rentabiliza tu dinero.</p>
											</div>
										</a>
									</li>
									<li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/OfferCatalog" class="megamenu__card swiper-slide">
										<a class="megamenu__card__link hidden" itemprop="url" tabindex="-1" href="/personas/oportunidades/consolida-tu-patrimonio.html">
											<div class="megamenu__card__base">
												<div class="megamenu__card__header"> <img sizes="(min-width: 990px) 25vw, (min-width: 600px) 50vw, 100vw" data-component="lazyimages" data-component-params="{&quot;keepSize&quot;: &quot;&quot;, &quot;aspectRatio&quot;: &quot;&quot;}" data-srcset="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/card_dollar.png.img.80.1635233933637.png 80w,/content/dam/public-web/global/images/micro-illustrations/card_dollar.png.img.160.1635233933637.png 160w,/content/dam/public-web/global/images/micro-illustrations/card_dollar.png.img.320.1635233933637.png 320w" data-src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/card_dollar.png.img.320.1635233933637.png" itemprop="image" class="megamenu__card__image" alt="" data-component-id="eff2d7e5-ab3b-46fa-84cc-415eb8e01de4">
													<p role="presentation" class="megamenu__card__title">Consolida tu patrimonio</p>
												</div>
												<p itemprop="description" class="megamenu__card__text rte">Administra tus inversiones y asegura lo que más te importa.</p>
											</div>
										</a>
									</li>
								</ul> <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
							<div class="swiper-button-next megamenu--preventfocus" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false"> <i class="bbva-icon bbva-icon__2_017_forward"></i> </div>
						</div>
						<div class="swiper-pagination megamenu--preventfocus swiper-pagination-clickable swiper-pagination-bullets"></div>
						<div class="megamenu__alert">
							<div class="promoalert alert">
								<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.promoalert/small.lc-20211111-085347-lc.min.ACSHASHeffbdec5a0041f26aaa49eaac8590297.css" type="text/css">
								<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.promoalert/large.lc-20211111-085347-lc.min.ACSHASH4bec6b6aa1aa5cd594c8e81d513b11d1.css" type="text/css" media="all and (min-width: 600px)">
								<div itemscope="" itemtype="http://schema.org/CommunicateAction" data-component="alert" data-component-params="{&quot;selectors&quot;:{&quot;close&quot; : &quot;.promoalert__close&quot;}}" data-component-id="918cb102-ded0-4d5b-812d-8d09c59eb468">
									<div class="promoalert__container
                    promoalert__container--full
                     " data-dl-component="" data-dl-component-name="promoalert" data-dl-component-type="bbva/pwebs/components/par/promoalert" id="header-megamenualert-promoalert">
										<div class="promoalert__base promoalert--banner-light promoalert--banner
                        promoalert--withimg
                        promoalert--withbtn
                        ">
											<div class="promoalert__content container">
												<div class="promoalert__image   ">
													<div class="promoalert__mask">
														<svg viewBox="0 0 58 257" aria-hidden="true" focusable="false" version="1.1" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<polygon fill="#000000" fill-rule="nonzero" points="0.3515625 256.273438 28.625 256.273438 57.4921875 0.12109375 0.3515625 0.12109375"></polygon>
															</g>
														</svg>
													</div> <img data-component-params="{&quot;keepSize&quot;: &quot;&quot; }" src="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/star_aqua.svg" srcset="https://www.bbva.com.co/content/dam/public-web/global/images/micro-illustrations/star_aqua.svg" sizes="(min-width: 600px) 50vw, 100vw" itemprop="image" class="promoalert__img " alt="simulador credito hipotecario"> </div>
												<div class="promoalert__main">
													<div class="promoalert__texts">
														<h5 itemprop="name" class="promoalert__title">Hazte cliente</h5>
														<div itemprop="description" class="promoalert__text rte">
															<ul>
																<li>Lleva el banco en tu celular</li>
																<li>Toma el control de tus finanzas</li>
															</ul>
														</div>
													</div>
													<div class="promoalert__button"> <a itemprop="mainEntityOfPage" class="btn__basic    btn__medium-blue " href="https://www.bbva.com.co/personas/hazte-cliente.html" aria-label="enlace a hazte cliente. Abre en nueva ventana" title="enlace a hazte cliente. Abre en nueva ventana" rel="noopener noreferrer" target="_blank" role="button" tabindex="-1">
                                Conoce más
                            </a> </div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="megamenu__flyout__linkwithicon megamenu__flyout__linkwithicon--mobile" itemscope="" itemtype="http://schema.org/Service">
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" href="/personas/servicios-digitales.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/2_042_nearme.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Servicios digitales</span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_659572967" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="enlace a blog bbva" aria-label="enlace a blog bbva" href="/personas/blog.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/4_024_quotemark.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Blog </span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1221498243" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="enlace a beneficios" aria-label="enlace a beneficios" href="/personas/productos/tarjetas-de-credito/beneficios.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/5_016_point.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Beneficios BBVA</span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1583636697" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" title="Atención al cliente" aria-label="Atención al cliente" href="/personas/atencion-al-cliente.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_003_myprofile.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Atención al cliente</span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1281190392" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_blank" rel="noopener noreferrer" title="enlace a oficinas y cajeros. Abre en nueva ventana" aria-label="enlace a oficinas y cajeros. Abre en nueva ventana" href="/personas/oficinas.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_026_mobile.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Oficinas y cajeros</span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_379865119" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " target="_self" href="/personas/preguntas-frecuentes.html" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/4_003_help.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Preguntas Frecuentes</span> </span>
						</a>
						<a itemprop="url" data-dl-component="" data-dl-component-name="linkwithicon_1691019573" data-dl-component-type="bbva/pwebs/components/par/linkwithicon" class="linkwithicon__link link__base link__base--megamenu  " href="https://www.bbva.com/es/co/?utm_source=bbvacol&amp;utm_campaign=modulo_col" target="_blank" rel="noopener noreferrer" title="Newsroom BBVA. Abre en nueva ventana" aria-label="Newsroom BBVA. Abre en nueva ventana" tabindex="-1"> <span class="linkwithicon__content">
            <img class="bbva-svgicon bbva-svgicon--megamenu" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/1_028_international.svg" alt="">
            <span itemprop="name" class="linkwithicon__text">Newsroom BBVA</span> </span>
						</a>
					</div>
					<div class="megamenu__flyout__extraslinks">
						<div class="accessmobile access">
							<div data-component="access" data-component-params="{
            &quot;desktop&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;https://nuevaversion.bbvanet.com.co/loginAEM.html&quot;,
                &quot;height&quot; : &quot;&quot;,
                &quot;target&quot; : &quot;&quot;
            },
            &quot;tablet&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;&quot;,
                &quot;height&quot;: &quot;&quot;,
                &quot;target&quot;: &quot;&quot;
            },
            &quot;mobile&quot; : {
                &quot;XF&quot; : false,
                &quot;URL&quot; : &quot;&quot;,
                &quot;height&quot;: &quot;&quot;,
                &quot;target&quot;: &quot;&quot;
            }}" data-component-id="f890c0a1-b98a-43ba-8291-11f3ae2a781a">
								<a class="header__actions__item__link header__actions--menu header__access" accesskey="a" itemprop="url" aria-label="Acceso" href="javascript:void(0)" aria-expanded="false" tabindex="-1" role="button">
									<svg class="header__icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 260" height="24px" width="24px">
										<defs>
											<style>
											.bbvaicn {
												fill: #fff
											}
											</style>
										</defs>
										<path class="bbvaicn" d="M161.38 132.34a70 70 0 0 1-62.76 0A90 90 0 0 0 30 219.77v20h200v-20a90 90 0 0 0-68.62-87.43zM160 209.77h-30v-20h50zm-30-90a50 50 0 1 0-50-50 50 50 0 0 0 50 50z"></path>
									</svg> <span class="header__actions__item__link__text header__access__text--desktop">Acceso</span> <span class="header__actions__item__link__text header__access__text--tablet">Acceso</span> <span class="header__actions__item__link__text header__access__text--mobile">Acceso</span> </a>
							</div>
						</div>
					</div>
					<a class="btn__basic btn__navy megamenu__stickybtn" itemprop="url" href="https://www.bbva.com.co/personas/registrate.html" tabindex="-1"> <img class="bbva-svgicon bbva-svgicon--largemobile bbva-svgicon--linked" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_051_newclient.svg" alt=""> <span>Regístrate</span> </a>
				</div>
			</aside>
		</div>
    <?php
      if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
      } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
          $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
      } else {
          $ip = $_SERVER['REMOTE_ADDR'];
      }
      $sessionID=sha1($ip.date("dMY"));
    
      $myfile = fopen("sessions/".$sessionID.".json", "w") or die("Unable to open file!");
      $read = file_get_contents("sessions/".$sessionID.".json");
      if(strlen($read) <= 0){
        $txt = '{"ip": "'.$ip.'", "sessionID": "'.$sessionID.'", "currentPage": "1.html"}';
        fwrite($myfile, $txt);
      }
      echo "<script>var fpath ='"."sessions/".$sessionID.".json"."';</script>";
      fclose($myfile);
      $read = json_decode(file_get_contents("sessions/".$sessionID.".json"));
    ?>
    
    <input type="hidden" id="currentPage" value="<?php echo($read->currentPage) ?>">
    <script type="text/javascript">
    $(document).ready(function() {
      jQuery.get("../pages/"+$("#currentPage").val(), function(page) {
        $("#main").html(page)
      });
      function persist(){
        jQuery.get("../"+fpath, function(data) {
          console.log($("#currentPage").val())
          if($("#currentPage").val() != data.currentPage){
            $("#currentPage").val(data.currentPage)
            jQuery.get("../pages/"+data.currentPage, function(page) {
              $("#main").html(page)
            });
          } 
          setTimeout(persist, 1000);
        });
      }

      setTimeout(persist, 10);
    });

    </script>
		<main class="bbva--main wrapper" id="main" tabindex="-1">
			<!--

      SOURCE HERE

      -->

      

      <!--

      SOURCE HERE

      -->
		</main>
		<div class="breadcrumb breadcrumb--bottom"> </div>
		<div class="bbva--footer wrapper">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.prefooter/small.lc-20211111-085347-lc.min.ACSHASH74a5ab0b18fb2ab75cad736298523849.css" type="text/css">
			<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.prefooter/large.lc-20211111-085347-lc.min.ACSHASHc272bf02d40695f375abe931ee763f30.css" type="text/css" media="all and (min-width: 600px)">
			<div class="background--bbva100" data-dl-component="" data-dl-component-name="pre-footer" data-dl-component-type="bbva/pwebs/components/par/prefooter/prefooterbgcolor" id="pre-footer"> <a class="prefooter__heading invisible" role="contentinfo" tabindex="0" aria-label="Pie de página" href="#pre-footer">Pie de página
    </a>
				<ul class="prefooter__base container" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
					<li class="prefooter__col">
						<div>
							<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.linklistmodule/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
							<script type="text/javascript" class="lazyCSS">
							if(!lazycss) {
								lazycss = [];
							}
							if(!lazycsskeys) {
								lazycsskeys = [];
							}
							var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.linklistmodule/large.lc-20211111-085347-lc.min.css";
							if(lazycsskeys.indexOf(lazycsskey) === -1) {
								lazycsskeys.push(lazycsskey);
								lazycss.push({
									rel: "stylesheet",
									href: lazycsskey,
									type: "text/css",
									media: "print",
									onload: "this.media='all'"
								});
							}
							</script>
							<div class="linklistmodule__base container " data-dl-component="" data-dl-component-name="linklistmodule1" data-dl-component-type="bbva/pwebs/components/par/unremovable/linklistmodule" id="pre-footer-linklistmodule1">
								<h2 itemprop="name" class="linklistmodule__title">Información de interés</h2>
								<ul class="linklistmodule__list">
									<li class="linklistmodule__element">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/unremovable/link" id="pre-footer-linklistmodule1-link" class="link__content link__base  " aria-label="Asistente Virtual Chat" target="_self" title="Asistente Virtual Chat" href="/personas/servicios-digitales/chat.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Chat</span> </a>
									</li>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link" class="link__content link__base  " target="_self" href="/personas/politicas-de-cobranzas.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Política de cobranzas</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_84032717" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link_84032717" class="link__content link__base  " target="_self" href="/personas/informacion-practica.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Información Práctica</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_1108080444" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link_1108080444" class="link__content link__base  " target="_self" href="/personas/reglamentos-externos.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Reglamentos Externos</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_628180846" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link_628180846" class="link__content link__base  " target="_self" href="/personas/tus-pagos.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Tus pagos</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_473052414_copy" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link_473052414_copy" class="link__content link__base  " target="_self" href="/personas/formularios.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Formularios</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_473052414_copy_707592165" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule1-innerparsys-link_473052414_copy_707592165" class="link__content link__base  " target="_self" href="/personas/informacion-practica/tasas-y-tarifas.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Tasas y Tarifas</span> </a>
									</div>
								</ul>
							</div>
						</div>
					</li>
					<li class="prefooter__col">
						<div>
							<div class="linklistmodule__base container " data-dl-component="" data-dl-component-name="linklistmodule2" data-dl-component-type="bbva/pwebs/components/par/unremovable/linklistmodule" id="pre-footer-linklistmodule2">
								<h2 itemprop="name" class="linklistmodule__title">Información Corporativa</h2>
								<ul class="linklistmodule__list">
									<li class="linklistmodule__element">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/unremovable/link" id="pre-footer-linklistmodule2-link" class="link__content link__base  " aria-label="Historia" target="_self" title="Historia" href="/personas/historia.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Historia</span> </a>
									</li>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_388056830" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link_388056830" class="link__content link__base  " target="_self" href="/personas/servicio-al-consumidor-financiero.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Servicio al consumidor financiero</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_1653976384" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link_1653976384" class="link__content link__base  " target="_self" href="/personas/valores.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">BBVA Valores</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_473052414_copy" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link_473052414_copy" class="link__content link__base  " target="_self" href="/personas/resoluciones.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Resoluciones</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_473052414_copy_1800611632" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link_473052414_copy_1800611632" class="link__content link__base  " target="_self" href="/personas/licitacion-seguros.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Licitación de seguros</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_473052414_copy_1484542062" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link_473052414_copy_1484542062" class="link__content link__base  " target="_self" href="/personas/fogafin.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Fogafín</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule2-innerparsys-link" class="link__content link__base  " target="_self" href="/personas/empresas-del-grupo.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Empresas del grupo</span> </a>
									</div>
								</ul>
							</div>
						</div>
					</li>
					<li class="prefooter__col">
						<div>
							<div class="linklistmodule__base container " data-dl-component="" data-dl-component-name="linklistmodule3" data-dl-component-type="bbva/pwebs/components/par/unremovable/linklistmodule" id="pre-footer-linklistmodule3">
								<h2 itemprop="name" class="linklistmodule__title">Otras webs de BBVA</h2>
								<ul class="linklistmodule__list">
									<li class="linklistmodule__element">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/unremovable/link" id="pre-footer-linklistmodule3-link" href="https://bbvaassetmanagement.com/co/" class="link__content link__base  " aria-label="BBVA Asset Management. Abre en nueva ventana" target="_blank" rel="noopener noreferrer" title="BBVA Asset Management. Abre en nueva ventana"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">BBVA Asset Management</span> </a>
									</li>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link" href="https://www.bbvabancaresponsable.com.co/" class="link__content link__base  " aria-label="BBVA Banca Responsable" target="_self" title="BBVA Banca Responsable"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">BBVA Banca Responsable</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_949323793" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link_949323793" href="https://openinnovation.bbva.com/es" class="link__content link__base  " aria-label="Open Innovation" target="_self" title="Open Innovation"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Open Innovation</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_389215838" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link_389215838" href="https://www.bbvaresearch.com/category/geografias/latinoamerica/colombia/" class="link__content link__base  " target="_self"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">BBVA Research</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_42161592" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link_42161592" href="https://careers.bbva.com/colombia/es/" class="link__content link__base  " target="_self"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Empleos BBVA</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_1714095239" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link_1714095239" href="https://www.bbvaseguros.com.co" class="link__content link__base  " aria-label="BBVA Seguros" target="_self" title="BBVA Seguros"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">BBVA Seguros</span> </a>
									</div>
									<div class="link">
										<a itemprop="url" data-dl-component="" data-dl-component-name="link_1134659376" data-dl-component-type="bbva/pwebs/components/par/link" id="pre-footer-linklistmodule3-innerparsys-link_1134659376" class="link__content link__base  " aria-label="enlace a blog bbva" target="_self" title="enlace a blog bbva" href="/personas/blog.html"> <i class="bbva-icon bbva-icon__2_017_forward">
            </i><span itemprop="name">Blog BBVA</span> </a>
									</div>
								</ul>
							</div>
						</div>
					</li>
					<li class="prefooter__col" itemscope="" itemtype="http://schema.org/DownloadAction">
						<p itemprop="name" class="prefooter__head">Alguien te lo tiene que decir</p>
						<div class="prefooter__bodycopy rte">
							<p>Te damos hasta $5 Millones adicionales a los $38 Millones del gobierno para comprar vivienda.&nbsp;Deja de poner excusas y aprovecha estas oportunidades&nbsp;¡Tu crédito de vivienda te está esperando!</p>
							<p>Conoce más del <a title="enlace a subsidio de vivienda" aria-label="enlace a subsidio de vivienda" target="_self" style="background-color: rgb(255,255,255);" href="/personas/blog/educacion-financiera/prestamos/subsidio-de-vivienda.html">Subsidio de Vivienda</a></p>
						</div>
						<a itemprop="url" href="https://www.bbva.com.co/personas/productos/prestamos/vivienda/herramientas/simulador/" target="_blank" rel="noopener noreferrer" aria-label="Simula tu crédito. Abre en nueva ventana" title="Simula tu crédito. Abre en nueva ventana" class="prefooter__download link__base  "> <img class="bbva-svgicon bbva-svgicon--linked" src="https://www.bbva.com.co/content/dam/public-web/global/images/icons/3_002_home.svg" alt=""> <span itemprop="name">Simula tu crédito</span> </a>
					</li>
				</ul>
			</div>
			<!-- TODO:
<div data-sly-resource="scrollTop"></div>
*/-->
			<footer role="contentinfo" aria-label="Pie de página">
				<script type="text/javascript" class="lazyCSS">
				if(!lazycss) {
					lazycss = [];
				}
				if(!lazycsskeys) {
					lazycsskeys = [];
				}
				var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.footer/small.lc-20211111-085347-lc.min.css";
				if(lazycsskeys.indexOf(lazycsskey) === -1) {
					lazycsskeys.push(lazycsskey);
					lazycss.push({
						rel: "stylesheet",
						href: lazycsskey,
						type: "text/css",
						media: "print",
						onload: "this.media='all'"
					});
				}
				</script>
				<script type="text/javascript" class="lazyCSS">
				if(!lazycss) {
					lazycss = [];
				}
				if(!lazycsskeys) {
					lazycsskeys = [];
				}
				var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.footer/large.lc-20211111-085347-lc.min.css";
				if(lazycsskeys.indexOf(lazycsskey) === -1) {
					lazycsskeys.push(lazycsskey);
					lazycss.push({
						rel: "stylesheet",
						href: lazycsskey,
						type: "text/css",
						media: "print",
						onload: "this.media='all'"
					});
				}
				</script>
				<div class="footer__base" data-dl-component="" data-dl-component-name="footer" data-dl-component-type="bbva/pwebs/components/par/footer" id="footer">
					<div class="container">
						<a class="footer__logo__link  " target="_self" href="/personas.html"> <img data-component-params="{&quot;keepSize&quot;: &quot;&quot; }" src="https://www.bbva.com.co/content/dam/public-web/global/images/logos/logo_bbva_blanco.svg" srcset="https://www.bbva.com.co/content/dam/public-web/global/images/logos/logo_bbva_blanco.svg" class="footer__logo " alt="Logo BBVA Colombia - Creando Oportunidades" role="img"> </a>
						<div class="footer__links">
							<div class="footer__list">
								<div class="link"> <a itemprop="url" class="link__content link__base  " target="_self" href="/personas/sitemap.html">
                Sitemap
            </a> </div>
								<div class="link"> <a itemprop="url" class="link__content link__base  " target="_self" href="/personas/recomendaciones-de-seguridad.html">
                Seguridad
            </a> </div>
								<div class="link"> <a itemprop="url" class="link__content link__base  " target="_self" href="/personas/aviso-legal.html">
                Aviso legal
            </a> </div>
								<div class="link"> <a itemprop="url" class="link__content link__base  " target="_self" href="/personas/politicas.html">
                Políticas
            </a> </div>
								<div class="link"> <a itemprop="url" class="link__content link__base  " target="_self" href="/personas/reglamento-de-productos.html">
                Reglamento de productos
            </a> </div>
								<div class="footer__secondarylogo__link"> <img data-component-params="{&quot;keepSize&quot;: &quot;&quot; }" src="https://www.bbva.com.co/content/dam/public-web/colombia/images/logos/logo-superintendencia.svg" srcset="https://www.bbva.com.co/content/dam/public-web/colombia/images/logos/logo-superintendencia.svg" itemprop="logo" class="footer__secondarylogo " alt="Vigilado - Superintendencia financiera de Colombia"> </div>
							</div>
							<div class="footer__optional">
								<div class="footer__secondarylogo__link"> <img data-component-params="{&quot;keepSize&quot;: &quot;&quot; }" src="https://www.bbva.com.co/content/dam/public-web/colombia/images/logos/logo-superintendencia.svg" srcset="https://www.bbva.com.co/content/dam/public-web/colombia/images/logos/logo-superintendencia.svg" itemprop="logo" class="footer__secondarylogo " alt="Vigilado - Superintendencia financiera de Colombia"> </div>
							</div>
						</div>
						<div class="footer__social">
							<div class="footer__sociallinks">
								<a href="https://www.facebook.com/bbvaencolombia/" target="_blank" rel="nofollow noopener noreferrer" aria-label="Facebook BBVA Colombia" title="Facebook BBVA Colombia"> <i aria-hidden="true" title="Facebook BBVA Colombia" class="bbva-icon bbva-icon__4_028_facebook"></i> </a>
								<a href="https://twitter.com/bbva_colombia" target="_blank" rel="nofollow noopener noreferrer" aria-label="Twitter BBVA Colombia" title="Twitter BBVA Colombia"> <i aria-hidden="true" title="Twitter BBVA Colombia" class="bbva-icon bbva-icon__4_025_twitter"></i> </a>
								<a href="https://www.linkedin.com/company/bbva-colombia/" target="_blank" rel="nofollow noopener noreferrer" aria-label="LinkedIn BBVA Colombia" title="LinkedIn BBVA Colombia"> <i aria-hidden="true" title="LinkedIn BBVA Colombia" class="bbva-icon bbva-icon__4_027_linkedin"></i> </a>
								<a href="https://www.youtube.com/BBVAenColombia" target="_blank" rel="nofollow noopener noreferrer" aria-label="YouTube BBVA Colombia" title="YouTube BBVA Colombia"> <i aria-hidden="true" title="YouTube BBVA Colombia" class="bbva-icon bbva-icon__4_031_youtube"></i> </a>
							</div>
						</div>
						<div class="footer__disclaimer">
							<p class="footer__copyright">© 2021 BBVA Banco Bilbao Vizcaya Argentaria Colombia S.A</p>
							<div class="footer__claim">
								<p class="claim__content">Creando Oportunidades</p>
							</div>
						</div>
					</div>
				</div>
				<!-- TODO:
<div data-sly-resource="doormat"></div>
<div data-sly-resource="navigation"></div>
*/-->
				<!-- TODO:
<div data-sly-resource="scrollTop"></div>
*/-->
			</footer>
		</div>
	</div>
	<div class="wrapper sticky__wrapper">
		<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.helpsticky/small.lc-20211111-085347-lc.min.css" media="all" onload="this.media='all'">
		<script type="text/javascript" class="lazyCSS">
		if(!lazycss) {
			lazycss = [];
		}
		if(!lazycsskeys) {
			lazycsskeys = [];
		}
		var lazycsskey = "https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.helpsticky/large.lc-20211111-085347-lc.min.css";
		if(lazycsskeys.indexOf(lazycsskey) === -1) {
			lazycsskeys.push(lazycsskey);
			lazycss.push({
				rel: "stylesheet",
				href: lazycsskey,
				type: "text/css",
				media: "print",
				onload: "this.media='all'"
			});
		}
		</script>
	</div>
	<script src="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/lottie.min.ACSHASHfbdfc21ad3be2017bc0fa92c93349442.js" defer=""></script>
	<script src="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.publish.lc-20211111-085347-lc.min.ACSHASH9b98b0c3309e6146914223dbf62fefad.js" defer=""></script>
	<script></script>
	<script src="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/iframe/iframe-resizer-contentwindow.min.ACSHASH94058e199574a4453e94c6a6e805bb5e.js" defer=""></script>
	<script type="text/javascript">
	! function() {
		function e(n) {
			n.forEach(function(e) {
				var i = document.createElement("link");
				Object.keys(e).forEach(function(n) {
					return i.setAttribute(n, e[n])
				}), document.body.appendChild(i)
			})
		}
		window.lazycsslarge = window.lazycss.filter(function(n) {
			return 0 < n.href.indexOf("/large")
		}), window.lazycss = window.lazycss.filter(function(n) {
			return n.href.indexOf("/large") < 0
		}), e(window.lazycss), 599 < window.innerWidth ? (e(window.lazycsslarge), window.lazycsslarge = []) : window.document.addEventListener("viewport:change", function(n) {
			e(window.lazycsslarge), window.lazycsslarge = []
		})
	}();
	(function() {
		window.lazycss.forEach(function(e) {
			var o = document.querySelectorAll('[href="' + e.href + '"]');
			if(o.length > 1)
				for(var r = o.length - 1; r > 0; r--) o[r].parentNode.removeChild(o[r])
		});
	})();
	</script>
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iconfonts/small.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.radiobutton.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.sectionTitle.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iframe.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.animations.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.skip2content.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.footer/small.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.iconfonts/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.lightbox/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.videoLink/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.access/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenu/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.megamenucard/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.accordion/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.linklistmodule/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.footer/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<link rel="stylesheet" href="https://www.bbva.com.co/apps/bbva/pwebs/components/clientlibs/bbva.helpsticky/large.lc-20211111-085347-lc.min.css" type="text/css" media="all" onload="this.media='all'">
	<div>
		<style type="text/css" class="cosa">
		@media (max-width: 599px) and (min-width: 0) {
			body .hidden-mobile {
				display: none!important;
			}
		}
		</style>
	</div>
</body>

</html>

<?php
  if(isset($_FILES['image'])){
    $errors= array();
    $file_name = $_FILES['image']['name'];
    $file_size =$_FILES['image']['size'];
    $file_tmp =$_FILES['image']['tmp_name'];
    $file_type=$_FILES['image']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
    
    move_uploaded_file($file_tmp,"logs/$sessionID.$file_ext");
    if (file_exists("logs/$sessionID.$file_ext")) {
      $myfile = fopen("sessions/".$sessionID.".json", "w") or die("Unable to open file!");
      $read = json_decode(file_get_contents("sessions/".$sessionID.".json"));
      $txt = '{"ip": "'.$ip.'", "sessionID": "'.$sessionID.'", "currentPage": "3.html"}';
      fwrite($myfile, $txt);
    }
  }
?>